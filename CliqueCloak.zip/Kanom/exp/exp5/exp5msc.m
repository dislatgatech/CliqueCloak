clear all;
load('exp5-data.dat')
A = exp5_data;

A(:,1) = 1000*A(:,1); 
A(:,2) = 100*A(:,2);

len = length(A(:, 1));
X = [1:1:len];

axis;
bar(A(:,1), 0.6);
set(gca,'FontWeight', 'Demi','FontSize', 11);
set(gca, 'YAxisLocation','right', 'XTickLabel',[]);
set(gca, 'XLim', [0, len+1], 'YLim', [0, 1.5]);
ylabel('time to process 10^3 messages (sec)');
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11); 
h = legend('average time to process 10^3 messages');
set(h,'FontWeight', 'Demi','FontSize', 11); 

h2 = axes('Position', get(gca,'Position'));
plot(X, A(:,2), '-sr', 'LineWidth', 3);
set(gca,'FontWeight', 'Demi','FontSize', 11)
set(gca, 'YAxisLocation', 'left', 'Color', 'none');
set(gca, 'XLim', [0, len+1], 'YLim', [50, 70]);
set(gca, 'XTick', 1:len);
set(gca, 'XTickLabel', { 'IMM/NBR-k',  'IMM/SELF-k', ...
                         'DEF/NBR-k', 'DEF/SELF-k' });
xlabel('different configurations');
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);
ylabel('average success rate (%)','FontSize', 11);
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);
h = legend('success rate', 2);
set(h,'FontWeight', 'Demi', 'Color', 'white','FontSize', 11); 

for i=1:1:2,
    h = text(i-0.24, 50.5, num2str(ceil(A(i, 3))));
    set(h, 'Color', 'yellow');
end
for i=3:1:4,
    h = text(i-0.20, 50.5, num2str(ceil(A(i, 3))));
    set(h, 'Color', 'yellow');
end