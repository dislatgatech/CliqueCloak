clear all;
n_t = 5;
load('exp9-data.dat')
A = exp9_data;

len = length(A(:,1));
T = reshape(A(:,1), n_t, len/n_t);
S = reshape(A(:,2), n_t, len/n_t);
Z1 = reshape(A(:,3), n_t, len/n_t);
Z2 = reshape(A(:,4), n_t, len/n_t);

subplot(1,2,1);
surf(T, S, Z1);
xlabel(char('mean temporal', 'tolerance (sec)'));
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);
ylabel(char('mean spatial', 'tolerance (m)'));
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);
zlabel(char('average temporal extent', 'of cloaking box (m)'));
set(get(gca,'ZLabel'),'FontWeight','Demi','FontSize', 11);
set(gca,'FontWeight', 'Demi','FontSize', 11); 

subplot(1,2,2);
surf(T, S, Z2);
xlabel(char('mean temporal', 'tolerance (sec)'));
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);
ylabel(char('mean spatial', 'tolerance (m)'));
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);
zlabel(char('average spatial extent', 'of cloaking box (m)'));
set(get(gca,'ZLabel'),'FontWeight','Demi','FontSize', 11);
set(gca,'FontWeight', 'Demi','FontSize', 11);