%% Load data and display
clear all;
load('exp12-data.dat')
exp12_data 

%% Extract series
LS =  union(exp12_data(:,1),[]);
LK =  union(exp12_data(:,2),[]);
NS = length(LS);
NK = length(LK);

lstr = cell(1,NK);
for i=1:NK,
    lstr{i} = ['k = ' num2str(LK(i))]; 
    idx = find(exp12_data(:,2)==LK(i));
    Y1(:,i) = exp12_data(idx,3);
    Y2(:,i) = exp12_data(idx,4);
    Y3(:,i) = int8 (100 - 100 * exp12_data(idx,5));
end
X = LS;
xstr = cell(1,NS);

bar(X, Y2);
set(gca, 'XTickLabel', xstr);
obh = gca;
hold;
bh = bar(X, Y1);
%set(gca, 'XLim', get(obh, 'XLim') );
%set(gca, 'YLim', get(obh, 'YLim') );

set(gca,'FontWeight', 'Demi','FontSize', 11, 'Color', 'none'); 
h = legend(lstr, 'FontSize', 11, 'FontWeight', 'Demi');
xlabel('Scaling Factor','FontWeight','Demi','FontSize', 11);
ylabel('time to process 10^3 messages (sec)','FontWeight','Demi','FontSize', 11);
for i=1:NK,
    ch = get(bh(i), 'Children');
    dt = get(ch, 'XData');
    for j=1:NS,
        px = dt(1,j);
        py = Y2(j, i);
        tx = [num2str(Y3(j, i)) '%'];
        text(px, 0.1+py, tx);
    end
end 

xstr = cell(1, NS+2);
for i=1:NS,
    xstr{1+i} = num2str(LS(i));
end
xstr{1} = '';
xstr{end} = '';
set(gca, 'XTickLabel', xstr);


