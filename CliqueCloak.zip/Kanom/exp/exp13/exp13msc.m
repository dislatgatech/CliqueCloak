function dummy = exp13msc()

% Load data and display
clear all;
load('exp13-data.dat')
exp13_data 

%% Extract series
LS =  union(exp13_data(:,2),[]);
LK =  union(exp13_data(:,3),[]);
NS = length(LS);
NK = length(LK);

idx1 = find2(exp13_data(:,[1, 3]), [0.0 LK(end)]);
idx2 = find2(exp13_data(:,[1, 3]), [1.0 LK(end)]);
X = LS;
Y1 = [exp13_data(idx1,5) exp13_data(idx2,5)];
Y3 = [exp13_data(idx1,4) exp13_data(idx2,4)];
lstr1 = {['one-time, k= ' num2str(LK(end))], ['progressive, k= ' num2str(LK(end))]};

lstr2 = cell(1,NK);
for i=1:NK,
    lstr2{2*i-1} = ['one-time, k = ' num2str(LK(i))]; 
    lstr2{2*i} = ['progressive, k = ' num2str(LK(i))]; 
    idx1 = find2(exp13_data(:,[1,3]), [0.0 LK(i)]);
    idx2 = find2(exp13_data(:,[1,3]), [1.0 LK(i)]);
    Y2(:,2*i-1) = exp13_data(idx1,4);
    Y2(:,2*i) = exp13_data(idx2,4);
end

set(gcf,'DefaultAxesColorOrder', [0 0 0], ...
        'DefaultAxesLineStyleOrder', '-x|-o|-+|-*|-d|-s|-p|-h|-^|v|->|-<|-.');

subplot(3,1,1);
plot(X, Y1);
set(gca,'FontWeight', 'Demi','FontSize', 11); 
h = legend(lstr1, 'FontSize', 11, 'FontWeight', 'Demi');
xlabel('Scaling Factor','FontWeight','Demi','FontSize', 11);
ylabel('Time to process 10^3 messages','FontWeight','Demi','FontSize', 11);

subplot(3,1,2);
plot(X, Y1./Y3);
set(gca,'FontWeight', 'Demi','FontSize', 11); 
h = legend(lstr1, 'FontSize', 11, 'FontWeight', 'Demi');
xlabel('Scaling Factor','FontWeight','Demi','FontSize', 11);
ylabel('Adjusted message processing time','FontWeight','Demi','FontSize', 11);

subplot(3,1,3);
plot(X, 100*Y2);
set(gca,'FontWeight', 'Demi','FontSize', 11); 
h = legend(lstr2, 'FontSize', 11, 'FontWeight', 'Demi');
xlabel('Scaling Factor','FontWeight','Demi','FontSize', 11);
ylabel('Success Rate','FontWeight','Demi','FontSize', 11);


function res = find2(A, a) 

len = size(A, 1);
res = [];
for i=1:len,
    if(land(A(i,:)==a)==1)
        res = [res i];
    end
end

function res = land(ops)

if( isempty(find(ops==false)) )
    res = true;
else
    res = false;
end
