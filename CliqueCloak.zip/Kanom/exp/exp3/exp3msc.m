n_s = 5;
load('exp3-data.dat')
A = exp3_data;

len = length(A(:,1));
I = reshape(A(:,1), n_s, len/n_s);
T = reshape(A(:,2), n_s, len/n_s);
Z = 100*reshape(A(:,3), n_s, len/n_s);

surf(I, T, Z);
xlabel('mean inter-wait time (sec)');
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);
ylabel('mean spatial tolerance (m)');
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);
zlabel('average success rate (%)');
set(get(gca,'ZLabel'),'FontWeight','Demi','FontSize', 11);
set(gca,'FontWeight', 'Demi','FontSize', 11); 
