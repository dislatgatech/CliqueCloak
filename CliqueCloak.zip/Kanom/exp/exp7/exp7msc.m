clear all;
load('exp7-data.dat')
A = exp7_data;

for i=2:11,
    A(:, i) = A(:, i) / A(end, i); 
end

subplot(1, 2, 1);
semilogx(A(:,1), A(:,2), '-.', ...
         A(:,1), A(:,3), '--', ...
         A(:,1), A(:,4), '-', ...
         A(:,1), A(:,5), ':', ...
         A(:,1), A(:,6), '-.');
set(gca,'XLim', [1, 100], 'XTick',[1, 2, 4, 8, 16, 32, 64]);
set(gca,'FontWeight', 'Demi');
xlabel('relative temporal resolution');
set(get(gca,'XLabel'),'FontWeight','Demi');
ylabel('cumulative distribution of messages');
set(get(gca,'YLabel'),'FontWeight','Demi');
h = legend('sf = 0.5','sf = 0.75','sf = 1','sf = 1.25','sf = 1.5');
set(h,'FontWeight','Demi');

subplot(1, 2, 2);
semilogx(A(:,1), A(:,7), '-.', ...
         A(:,1), A(:,8), '--', ...
         A(:,1), A(:,9), '-', ...
         A(:,1), A(:,10), ':', ...
         A(:,1), A(:,11), '-.');
set(gca,'XLim', [1, 100], 'XTick',[1, 2, 4, 8, 16, 32, 64]);
set(gca,'FontWeight', 'Demi');
xlabel('relative spatial resolution');
set(get(gca,'XLabel'),'FontWeight','Demi');
ylabel('cumulative distribution of messages');
set(get(gca,'YLabel'),'FontWeight','Demi');
h = legend('sf = 0.5','sf = 0.75','sf = 1','sf = 1.25','sf = 1.5');
set(h,'FontWeight','Demi');