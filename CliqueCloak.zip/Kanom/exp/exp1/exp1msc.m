clear all;
load('exp1-data.dat')
A = exp1_data;

bar(A(:, 1), 100*(A(:, [3,5])+A(:, [2,4])), 0.6);
hold;
bar(A(:, 1), 100*A(:, [2,4]));

ylabel('average success rate (%)', 'FontWeight', 'Demi');
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);
xlabel('k (as specified by the input message)', 'FontWeight', 'Demi','FontSize', 11);
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);
set(gca,'YLim', [0, 100]);
set(gca,'FontWeight', 'Demi','FontSize', 11); 

h = legend('NBR-k','SELF-k',1);
set(h,'FontWeight', 'Demi','FontSize', 11);
colormap summer;