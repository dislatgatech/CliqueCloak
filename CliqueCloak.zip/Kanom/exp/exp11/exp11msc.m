%% Load data and display
clear all;
load('exp11-data.dat')
exp11_data 

%% Extract series
LS =  union(exp11_data(:,1),[]);
LK =  union(exp11_data(:,2),[]);
NS = length(LS);
NK = length(LK);

lstr = cell(1,NK);
for i=1:NK,
    lstr{i} = ['k = ' num2str(LK(i))]; 
    idx = find(exp11_data(:,2)==LK(i));
    Y1(:,i) = exp11_data(idx,4);
    Y2(:,i) = exp11_data(idx,3);
end
X = LS;

set(gcf,'DefaultAxesColorOrder', [0 0 0], ...
        'DefaultAxesLineStyleOrder', '-x|-o|-+|-*|-d|-s|-p|-h|-^|v|->|-<|-.');

subplot(1,3,1);
plot(X, Y1);
set(gca,'FontWeight', 'Demi','FontSize', 11); 
h = legend(lstr, 'FontSize', 11, 'FontWeight', 'Demi');
xlabel('Scaling Factor','FontWeight','Demi','FontSize', 11);
ylabel('Time to process 10^3 messages','FontWeight','Demi','FontSize', 11);

subplot(1,3,2);
plot(X, 100*Y2);
set(gca,'FontWeight', 'Demi','FontSize', 11); 
h = legend(lstr, 'FontSize', 11, 'FontWeight', 'Demi');
xlabel('Scaling Factor','FontWeight','Demi','FontSize', 11);
ylabel('Success Rate','FontWeight','Demi','FontSize', 11);

subplot(1,3,3);
plot(X, Y1./Y2);
set(gca,'FontWeight', 'Demi','FontSize', 11); 
h = legend(lstr, 'FontSize', 11, 'FontWeight', 'Demi');
xlabel('Scaling Factor','FontWeight','Demi','FontSize', 11);
ylabel('Adjusted message processing time','FontWeight','Demi','FontSize', 11);

