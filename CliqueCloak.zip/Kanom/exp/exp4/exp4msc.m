load('exp4-data.dat')
A = exp4_data;

bar(A(:, 1), A(:, 2:3), 0.8);

ylabel('average relative anonymity level achieved', 'FontWeight', 'Demi','FontSize', 11);
xlabel('k (anonimity level as specified by the input message)', 'FontWeight', 'Demi','FontSize', 11);
set(gca,'FontWeight', 'Demi','FontSize', 11);
set(gca,'YLim',[0.9, max(max(A(:, 2:3)))]);

h = legend('NBR-k','SELF-k',1);
set(h,'FontWeight', 'Demi','FontSize', 11);
colormap summer;

line([min(A(:, 1))-0.5,max(A(:, 1))+0.5], [1,1], 'Color', 'red');