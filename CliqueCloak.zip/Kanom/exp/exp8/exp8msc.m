clear all;
load('exp8-data.dat')
A = exp8_data;

A(:, 2:end) = 100*A(:, 2:end); 
semilogx(A(:,1), A(:,2), '-x', ...
         A(:,1), A(:,3), '-o', ...
         A(:,1), A(:,4), '-s');
set(gca,'FontWeight', 'Demi','FontSize', 11);
xlabel('variance in spatial and temporal tolerances (\times mean)');
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);
ylabel('average success rate (%)');
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);

set(gca, 'YLim', [0, 100], 'XTick', A(:, 1));

h = legend('dt mean=15sec', 'dt mean=30sec', 'dt mean=60sec');
set(h,'FontWeight','Demi','FontSize', 11);
