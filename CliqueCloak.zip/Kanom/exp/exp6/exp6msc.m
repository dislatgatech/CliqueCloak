clear all;
load('exp6-data.dat')
A = exp6_data;

A(:, 2) = A(:, 2) / sum(A(:, 2));
A(:, 3) = A(:, 3) / sum(A(:, 3));

subplot(2, 1, 1);
semilogx(A(:,1), A(:,2), '-');
set(gca,'XLim', [1, 100], 'XTick',[1, 2, 4, 8, 16, 32, 64]);
set(gca,'FontWeight', 'Demi','FontSize', 11);

xlabel('relative temporal resolution');
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);

ylabel('frequency of messages');
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);

sum = 0;
ymx = max(A(:, 2));
len = length(A(:, 1));
bvec = [1 1 1];
for i=1:len,
    sum = sum + A(i,2);
    if (sum  >= 0.25 && bvec(1))
        bvec(1) = 0;
        line([A(i,1),A(i,1)], [0,ymx], 'Color', 'red', 'LineStyle', '--');
    elseif (sum  >= 0.5 && bvec(2))
        bvec(2) = 0;
        line([A(i,1),A(i,1)], [0,ymx], 'Color', 'green', 'LineStyle', '-.');
    elseif (sum  >= 0.75 && bvec(3))
        bvec(3) = 0;
        line([A(i,1),A(i,1)], [0,ymx], 'Color', 'blue', 'LineStyle', ':');
        break;
    end
end

subplot(2, 1, 2);
semilogx(A(:,1), A(:,3), '-');
set(gca,'XLim', [1, 100], 'XTick',[1, 2, 4, 8, 16, 32, 64]);
set(gca,'FontWeight', 'Demi','FontSize', 11);

xlabel('relative spatial resolution');
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);

ylabel('frequency of messages');
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);

sum = 0;
ymx = max(A(:, 3));
len = length(A(:, 1));
bvec = [1 1 1];
for i=1:len,
    sum = sum + A(i,3);
    if (sum  >= 0.25 && bvec(1))
        bvec(1) = 0;
        line([A(i,1),A(i,1)], [0,ymx], 'Color', 'red', 'LineStyle', '--');
    elseif (sum  >= 0.5 && bvec(2))
        bvec(2) = 0;
        line([A(i,1),A(i,1)], [0,ymx], 'Color', 'green', 'LineStyle', '-.');
    elseif (sum  >= 0.75 && bvec(3))
        bvec(3) = 0;
        line([A(i,1),A(i,1)], [0,ymx], 'Color', 'blue', 'LineStyle', ':');
        break;
    end
end