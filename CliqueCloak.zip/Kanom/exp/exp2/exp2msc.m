n_t = 6;
load('exp2-data.dat')
A = exp2_data;

len = length(A(:,1));
I = reshape(A(:,1), n_t, len/n_t);
T = reshape(A(:,2), n_t, len/n_t);
Z = 100*reshape(A(:,3), n_t, len/n_t);

surf(I, T, Z);
xlabel('mean inter-wait time (sec)');
set(get(gca,'XLabel'),'FontWeight','Demi','FontSize', 11);
ylabel('mean temporal tolerance (sec)');
set(get(gca,'YLabel'),'FontWeight','Demi','FontSize', 11);
zlabel('average success rate (%)');
set(get(gca,'ZLabel'),'FontWeight','Demi','FontSize', 11);
set(gca,'FontWeight', 'Demi','FontSize', 11); 

