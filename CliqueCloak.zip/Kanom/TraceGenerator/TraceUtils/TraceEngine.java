/*
 * Created on Jan 1, 2004
 */
package TraceGenerator.TraceUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.TreeMap;

import TraceGenerator.MapUtils.Map;
import TraceGenerator.MapUtils.Point;
import TraceGenerator.MapUtils.RoadSegment;

/**
 * @author Bugra Gedik
 */
public class TraceEngine {

	// duration is in hour
	public static void generateTrace(Map map, TraceConf tconf, double duration, BufferedOutputStream out) throws IOException{
		Random random = new Random((new Date()).getTime()); 
		
		int numberOfObjects = tconf.getNumberOfObjects();
		double[] objectDistribution = tconf.getObjectDistribution();
		double[] objectSpeedMeans = tconf.getObjectSpeedMeans();
		double[] objectSpeedDevs = tconf.getObjectSpeedDevs();
		double delta = tconf.getDelta();
		
		ArrayList[] segs = extractSegmentIds(map);
		
		PosRecord rec = new PosRecord();
		for(int objectId=0; objectId < numberOfObjects; objectId++) {
		    // set object type
			int objectType;
			double rval = random.nextDouble(); 
			for(objectType=0; objectType < objectDistribution.length; objectType++) 
				if( 0 > (rval-=objectDistribution[objectType]) ) break;
			// set initial speed
			double currSpeed = Math.abs(objectSpeedMeans[objectType] + objectSpeedDevs[objectType]*random.nextGaussian());
			// set initial segment
			int segIndex = (int) (segs[objectType].size()*random.nextDouble());
			RoadSegment currSegment = (RoadSegment) segs[objectType].get(segIndex);
			
			boolean goingForward = (random.nextDouble() < 0.5);  
			int currPointIndex = (int) Math.floor(random.nextDouble()*(currSegment.getNumberOfPoints()-1));
			
			// set initial position 
			double lamda = random.nextDouble();
			Point cp = currSegment.getPointAt(currPointIndex);
			Point np = currSegment.getPointAt(currPointIndex+1);
			Point currPosition = new Point(cp.getX()*lamda + (1-lamda)*np.getX(), 
			                               cp.getY()*lamda + (1-lamda)*np.getY());
			if(!goingForward) currPointIndex++; 			
			double currTime = 0;
			do {
                // write curr position and time
			    if(currTime > 0) { 
			        rec.init(currTime, objectId, currPosition.getX(), currPosition.getY());
			        out.write(rec.toByteArray());
			    }
                boolean nextSegment;
                boolean firstIter = true;
                do{ // calc new position
				   nextSegment = true;
				   int npts = currSegment.getNumberOfPoints();
				   int end = goingForward ? (npts-1) : (2*currPointIndex);
				   for(int li=currPointIndex; li<end; li++) {
					   currPointIndex = goingForward ? li : (end-li);
					   int nextPointIndex = currPointIndex + (goingForward ? 1 : -1);
	                   
					   Point nextPoint = currSegment.getPointAt(nextPointIndex);
					   double dist = currPosition.distance(nextPoint);

					   if( dist >= delta ) {
					   	    Point currPoint = currSegment.getPointAt(currPointIndex); 					   	    
					   	    Point oldPosition = currPosition;
					   	    if(firstIter) {
					   	        currPosition = findCrossPosition(currPosition, currPosition, nextPoint, delta);					   
					   	        assert(currPosition != null);
					   	    }
					   	    else {
					   	    	currPosition = findCrossPosition(currPosition, currPoint, nextPoint, delta);
					   	        assert(currPosition != null); 
					   	    }
                            if(!firstIter)
                            	dist = currPosition.distance(currPoint);
					   	    else 
					   	    	dist = currPosition.distance(oldPosition);
                            
                            currTime += 0.001*dist/currSpeed;					   	    
					   	    nextSegment = false;
					   	    firstIter = true;
					        break;
					   
					   } else {
					   	   if(!firstIter)    
					   	       dist = currSegment.getDistanceBetweenPoints(currPointIndex, nextPointIndex);
					   	   else 
					   	   	   firstIter = false;
					   	   currTime += 0.001*dist/currSpeed; 
					   }
				   }  
				   
				   if(nextSegment) {
				   	   int[] nbrIds = goingForward?currSegment.getEndNeighbors():currSegment.getStartNeighbors();
				   	   int nlen = nbrIds.length;
				   	   if(nlen == 0) {
				   	   	   currPointIndex = goingForward ? (currSegment.getNumberOfPoints()-1) : 0;
				   	   	   goingForward = !goingForward;
				   	   } else {
				   	       int nbrId = nbrIds[(int)(nlen*random.nextDouble())];
				   	   	   assert (nbrId != 0);
				   	   	   currSegment = map.getRoadSegment((int)Math.abs(nbrId));
				   	   	   goingForward = (nbrId > 0);
				   	   	   objectType = currSegment.getRoadClassIndex();
				   	   	   currSpeed = Math.abs(objectSpeedMeans[objectType] + objectSpeedDevs[objectType]*random.nextGaussian());				   	   
				   	   	   currPointIndex = goingForward ? 0 : (currSegment.getNumberOfPoints()-1);
				   	   }
				   }
			    } while(nextSegment && currTime <= duration);
			} while(currTime <= duration);
		}
	}
	
	private static Point findCrossPosition(Point currPosition, Point currPoint, Point nextPoint, double delta) {
		double cx = currPosition.getX();
		double cy = currPosition.getY();
		double x1 = currPoint.getX() - cx;  
		double y1 = currPoint.getY() - cy;  
		double x2 = nextPoint.getX() - cx;  
		double y2 = nextPoint.getY() - cy;  

		Point p1 = null, p2 = null;
		if(y1 == y2) {
			double y = y1;
			double d = delta*delta - y*y;
			double u = Math.sqrt(d);
			double v = -u;
			
			if( Math.min(x1, x2) <= u && u <= Math.max(x1, x2) ) {
				double x = u;
				p1 = new Point(x, y);
			}
			if( Math.min(x1, x2) <= v && v <= Math.max(x1, x2) ) {
				double x = v;
				p2 = new Point(x, y);
			}
		} else {
		    double a = (x2-x1)/(y2-y1);		
		    double b = x1 - a*y1;
		
	    	double A = 1 + a*a;
		    double B = 2 * a*b;
		    double C = b*b - delta*delta;
		    double D = Math.sqrt(B*B-4*A*C);
		
		    double u = 0.5*(-B+D)/A;
		    double v = 0.5*(-B-D)/A;
		
		    if( Math.min(y1, y2) <= u && u <= Math.max(y1, y2) ) { 
		        double y = u;
			    double x = a*y + b;     
			    if( Math.min(x1, x2) <= x && x <= Math.max(x1, x2) )
				    p1 = new Point(x, y);
		    }
		    
		    if( Math.min(y1, y2) <= v && v <= Math.max(y1, y2) ) {
	        	double y = v;
	    	    double x = a*y + b;     
	    	    if( Math.min(x1, x2) <= x && x <= Math.max(x1, x2) )
	    		    p2 = new Point(x, y);
	        }
		}
		
		Point p = null;
		if(p1 == null) 
			p = p2;
		else if(p2 == null) 
			p = p1;
		else {
			double d1 = p1.distance(currPoint);
			double d2 = p2.distance(currPoint);
			if(d1 < d2) p = p1;
			else p = p2;
		}	
		if(p == null) 
			return p;
		
		return new Point(p.getX()+cx, p.getY()+cy);		
	}
	
	private static int sign(double a) {
		if(a >= 0) return +1;
		return -1;	
	}
	
	private static ArrayList[] extractSegmentIds(Map map) {
		int numberOfTypes = map.getNumberOfRoadClasses();
		ArrayList[] ret = new ArrayList[numberOfTypes];
		
		for(int i=0; i<numberOfTypes; i++)
			ret[i] = new ArrayList();
		
		for(Iterator it=map.getSegmentIterator(); it.hasNext();) {
			RoadSegment segment = (RoadSegment) it.next();
			ret[segment.getRoadClassIndex()].add(segment);
		}		
		return ret;
	}

	public static void sortTraceDataFile(String inFileName, String outFileName) throws IOException{
		int mem = 25*1024*1024; // 25mb
				
		// partition into sorted files
		FileInputStream fr = new FileInputStream(inFileName);
		BufferedInputStream br = new BufferedInputStream(fr); 
		int fileNum = 0;		
		int ecnt = 0;
		int bcnt = mem / PosRecord.size;
		PosRecord[] records = new PosRecord[bcnt];
		byte[] buffer = new byte[PosRecord.size];
		while(true) { 
		    int rlen = br.read(buffer);
		    if(ecnt >= bcnt || rlen != buffer.length) { 
			    Arrays.sort(records, 0, ecnt);
				String tempFileName = outFileName + "." + fileNum;
				FileOutputStream fo = new FileOutputStream(tempFileName);
				BufferedOutputStream bo = new BufferedOutputStream(fo);
				for(int j=0; j<ecnt; j++) 
				    bo.write(records[j].toByteArray());
				
				bo.flush(); 
				bo.close();				
				if(rlen != buffer.length) {
				    records = null;
				    break;
				}
				ecnt = 0;
				fileNum = fileNum + 1;
			}
			records[ecnt] = PosRecord.fromByteArray(buffer);
			ecnt = ecnt + 1;
		}
		br.close();
				
		// merge step		 
		FileOutputStream fw = new FileOutputStream(outFileName);
		BufferedOutputStream bw = new BufferedOutputStream(fw);
		TreeMap heap = new TreeMap();
		BufferedInputStream[] bi = new BufferedInputStream[fileNum+1];
		boolean[] fileStatus = new boolean[fileNum+1];
		for(int i=0; i<=fileNum; i++) {
		    String tempFileName = outFileName + "." + i;
		    FileInputStream fi = new FileInputStream(tempFileName);
		    bi[i] = new BufferedInputStream(fi);
		    fileStatus[i] = true;
		    bi[i].read(buffer);
		    PosRecord rec = PosRecord.fromByteArray(buffer);
		    Object obj = heap.put(rec, new Integer(i));
		    assert(obj == null);
		}
		do {
		    PosRecord rec = (PosRecord) heap.firstKey();
		    int inFile = ((Integer) heap.get(rec)).intValue();
		    heap.remove(rec);
		    bw.write(rec.toByteArray());
		    if(fileStatus[inFile]) {
		       int rlen = bi[inFile].read(buffer);
		       if(rlen == buffer.length) {
		           rec = PosRecord.fromByteArray(buffer);
		           Object obj = heap.put(rec, new Integer(inFile));
		           assert(obj == null);
		       } else {
		           bi[inFile].close();
		           fileStatus[inFile] = false;
		           String tempFileName = outFileName + "." + inFile;
		           File file = new File(tempFileName);
		           file.delete();
		       }
		    }
		} while(!heap.isEmpty());
		bw.flush();
		bw.close();
		
		/*testFile
		System.err.println("Testing File");
		fr = new FileInputStream(inFileName);
		br = new BufferedInputStream(fr); 
		PosRecord prev = null, curr = null;
		while(br.read(buffer) == buffer.length) { 
		    curr = PosRecord.fromByteArray(buffer);
		    if(prev!=null && prev.compareTo(curr)>0)
		        System.err.println("Error");
		    prev = curr;
		}
		*/		    
		    
	}
}

class InvalidTraceFileException extends IOException {
	public String toString() {
		return "Invalid Trace File Exception";
	}
}


