/*
 * Created on Jan 10, 2004
 */
package TraceGenerator.TraceUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.StringTokenizer;

/**
 * @author Bugra Gedik
 */
public class PosRecord implements Comparable{
    private int id;
    private double t; // in hours
    private double x; // meters
    private double y; // meters
    
    static final int size = 28;
    public PosRecord(){}
    public PosRecord(double t, int id, double x, double y) {
        init(t, id, x, y);
    }
    public void init(double t, int id, double x, double y) {
        this.id = id;
        this.t = t;
        this.x = x;
        this.y = y;
    }
    
    public int getId() { return id; }
    public double getT() { return t; }
    public double getX() { return x; }
    public double getY() { return y; }
    
    public static PosRecord fromByteArray(byte[] buffer) {
        ByteArrayInputStream bis = new ByteArrayInputStream(buffer);
        DataInputStream dis = new DataInputStream(bis);
        try{
            double t = dis.readDouble();
            int id = dis.readInt();
            double x = dis.readDouble();
            double y = dis.readDouble(); 
            return new PosRecord(t, id, x, y);
        } catch(Exception e) {
            return null;
        }
    }
    
    public byte[] toByteArray() {
        ByteArrayOutputStream bas = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(bas);
        try{
            dos.writeDouble(t);
            dos.writeInt(id);
            dos.writeDouble(x);
            dos.writeDouble(y);
            dos.flush();
            dos.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
        return bas.toByteArray();
    }
    
    public String toString() {
        return t+"\t"+id+"\t"+x+"\t"+y;
    }
    
    public boolean compare(Object obj) {
        PosRecord crec = (PosRecord) obj;
        return id == crec.id; 
    }
    public int compareTo(Object obj) {
        PosRecord crec = (PosRecord) obj;
        if(t > crec.t)
            return 1;
        else if(t == crec.t)
            return id - crec.id;
        return -1;
    }
    public static PosRecord parse(String str) throws InvalidTraceFileException{
        StringTokenizer tok = new StringTokenizer(str);
        int id; double t, x, y;
        try {
            t = Double.parseDouble(tok.nextToken());
            id = Integer.parseInt(tok.nextToken()); 
            x = Double.parseDouble(tok.nextToken());
            y = Double.parseDouble(tok.nextToken());
        } catch(Exception e) {
            throw new InvalidTraceFileException();
        }
        return new PosRecord(t, id, x, y);
        
    }
}