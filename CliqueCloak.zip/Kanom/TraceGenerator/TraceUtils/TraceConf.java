/*
 * Created on Dec 20, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator.TraceUtils;

import java.io.*;

/**
 * @author Bugra Gedik
 *
 */
public class TraceConf{
	private int numberOfObjects;
	private String[] roadClassNames;
	private double[] objectDistribution;
	private double[] objectSpeedMeans;
	private double[] objectSpeedDevs;
	private double delta;
	
	public TraceConf(String[] roadClassNames,
				 int      numberOfObjects,
				 double[] objectDistribution, 
				 double[] objectSpeedMeans, 
				 double[] objectSpeedDevs, double delta) {
		this.numberOfObjects = numberOfObjects;
		this.roadClassNames = roadClassNames;
		this.objectDistribution = objectDistribution;
		this.objectSpeedMeans = objectSpeedMeans;
		this.objectSpeedDevs = objectSpeedDevs;
		this.delta = delta;
	}
	
	public int getNumberOfObjects() {
		return numberOfObjects;
	}
	public String[] getRoadClassNames() {
		return roadClassNames;
	}
	public double[] getObjectDistribution() {
		return objectDistribution;
	}
	public double[] getObjectSpeedMeans() {
		return objectSpeedMeans;
	}
	public double[] getObjectSpeedDevs() {
		return objectSpeedDevs;
	}
	public double getDelta() {
		return delta;
	}
	
	public String toString() {
		return null;
	}

	public static TraceConf fromFile(String file) throws IOException {
		BufferedInputStream bin = new BufferedInputStream(new FileInputStream(file));
		DataInputStream din = new DataInputStream(bin);		
		
        int numberOfObjects = din.readInt();
		int k = din.readInt();
		
        String[] roadClassNames = new String[k];
		double[] objectDistribution = new double[k];
		double[] objectSpeedMeans = new double[k]; 
		double[] objectSpeedDevs = new double[k];		
        
		for(int i=0; i<roadClassNames.length; i++) {
			roadClassNames[i] = din.readUTF();
			objectDistribution[i] = din.readDouble();
			objectSpeedMeans[i] = din.readDouble();
			objectSpeedDevs[i] = din.readDouble();
		}
		double delta = din.readDouble();
		
		din.close(); bin.close();
		return new TraceConf(roadClassNames, numberOfObjects, objectDistribution, 
		                                 objectSpeedMeans, objectSpeedDevs, delta);
	}
	
    public static void toFile(String file, TraceConf trace) throws IOException {
		BufferedOutputStream bot = new BufferedOutputStream(new FileOutputStream(file));
        DataOutputStream dot = new DataOutputStream(bot);
    	
    	int numberOfObjects = trace.getNumberOfObjects();
    	String[] roadClassNames = trace.getRoadClassNames();
    	double[] objectDistribution = trace.getObjectDistribution();
    	double[] objectSpeedMeans = trace.getObjectSpeedMeans();
    	double[] objectSpeedDevs = trace.getObjectSpeedDevs();
    	double delta = trace.getDelta();
    	
    	dot.writeInt(numberOfObjects);
    	dot.writeInt(roadClassNames.length);
    	for(int i=0; i<roadClassNames.length; i++) {
    		dot.writeUTF(roadClassNames[i]);
    		dot.writeDouble(objectDistribution[i]);
    		dot.writeDouble(objectSpeedMeans[i]);
    		dot.writeDouble(objectSpeedDevs[i]);
    	}
    	dot.writeDouble(delta);
    	
    	dot.flush(); dot.close();
    	bot.flush(); bot.close();
    }
}
