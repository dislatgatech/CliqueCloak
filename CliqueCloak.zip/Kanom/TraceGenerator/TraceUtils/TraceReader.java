/*
 * Created on Jan 11, 2004
 */
package TraceGenerator.TraceUtils;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * @author Bugra Gedik
 */
public class TraceReader {
    private BufferedInputStream bis = null;
    private String fileName = null;
    private byte[] buffer = null;
    
    public TraceReader(String fileName) {
        buffer = new byte[PosRecord.size];
        this.fileName = fileName;
    }
    
    public void open() throws IOException{
        FileInputStream fis = new FileInputStream(fileName);
        bis = new BufferedInputStream(fis);
    }
    
    public PosRecord next() throws IOException {
        int rlen = bis.read(buffer);
        if(rlen != buffer.length)
            return null;
        return PosRecord.fromByteArray(buffer);
    }
    
    public void close() throws IOException{
        bis.close();
    }  
    
    public static void main(String[] args) {
        TraceReader tr = new TraceReader("TraceDataTV.dat");
        try {	
        	tr.open();
        	PosRecord rec = null;
        	while(null != (rec = tr.next()) ) 
        	    System.err.println(rec);
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
