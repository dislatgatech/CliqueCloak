/*
 * Created on Dec 9, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator.MapUtils;
import TraceGenerator.MapUtils.Point;

/**
 * @author Bugrea Gedik
 *
 */
public class RoadSegment {
	private int[] startNeighbors = null;
	private int[] endNeighbors = null;
	private Point[] points = null;
	
	private double length;
	private int roadClassIndex;
	private int id;
	
	// points should not be altered after creation and should contain at least one point
	public RoadSegment(int id, int roadClassIndex, Point[] points) {
		this.id = id;
		this.roadClassIndex = roadClassIndex;
		this.points = points;
	}
	public int getId() {
		return id;
	}
	public int getRoadClassIndex() {
		return roadClassIndex;
	}	
	
	public Point getStartPoint() {
		return points[0];
	}
    
	public Point getEndPoint() {
		return points[points.length-1];
	}
	
	public int getNumberOfPoints() {
		return points.length;
	}
    
	public Point getPointAt(int index) {
		return points[index];
	}
	
	public double getTotalLength() {
		return getDistanceBetweenPoints(0, points.length-1); 
	}
	public double getDistanceBetweenPoints(int sindex, int eindex) {
		double length = 0;
		for(int i=sindex; i<eindex; i++)
			length += points[i].distance(points[i+1]);
		return length;	
	}	
	
	// parameters should not be modified after call
	protected void setStartNeighbors(int[] startNeighbors) {
		this.startNeighbors = startNeighbors;
	}
	public int[] getStartNeighbors() {
		return startNeighbors;
	}	
    // parameters should not be modified after call
	protected void setEndNeighbors(int[] endNeighbors) {
		this.endNeighbors = endNeighbors;
	}
	public int[] getEndNeighbors() {
		return endNeighbors;
	}
	
}
