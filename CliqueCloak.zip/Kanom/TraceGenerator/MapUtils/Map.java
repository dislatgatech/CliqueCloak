/*
 * Created on Dec 9, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator.MapUtils;
import TraceGenerator.MapUtils.Rectangle;

import java.util.HashMap;
import java.util.Iterator;

/**
 * @author Bugra Gedik
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Map {
	private Rectangle bounds = null;
	private String[] roadClassNames = null;
	private HashMap roadSegments = null;
    
	public Map(String[] roadClassNames) {
		int n = roadClassNames.length;
		this.roadClassNames = new String[n];
		for(int i=0; i<n; i++)
			this.roadClassNames[i] = new String(roadClassNames[i]);
		roadSegments = new HashMap();
	}
	
	public int getNumberOfRoadSegments() {
		return roadSegments.size();
	}
	
	public boolean addRoadSegment(RoadSegment segment) {
		Integer ID = new Integer(segment.getId());
		if( roadSegments.containsKey(ID) ) 
			return false;
		roadSegments.put(ID, segment);
		return true;
	}
	
	public RoadSegment getRoadSegment(int id) {
		Integer ID = new Integer(id);
		RoadSegment seg = (RoadSegment) roadSegments.get(ID);
		return seg;
	}	
	
	public Iterator getSegmentIterator() {
		return roadSegments.values().iterator();
	}
	
	// road class names functions
	
	public int getNumberOfRoadClasses() {
		return roadClassNames.length; 
	}
	public String getRoadClassName(int index) {
		return roadClassNames[index]; 
	}	
	public int getRoadClassIndex(String str) {
		for(int i=0; i<roadClassNames.length; i++) {
			if(str.indexOf(roadClassNames[i]) != -1)
				return i;
		}
		return -1;
	}	
	
	public double[] getRoadClassLengths() {
		if(roadClassNames == null) return null;
		double[] roadLengths = new double[roadClassNames.length];
		for(int i=0; i<roadClassNames.length; i++)
			roadLengths[i] = 0;
		Iterator it = roadSegments.values().iterator();
		while(it.hasNext()) {
			RoadSegment seg = (RoadSegment) it.next();
			roadLengths[seg.getRoadClassIndex()] += seg.getTotalLength();
		}
		return roadLengths;
	}
	
    // bound set/get functions
	
    public void setBounds(double xpos, double ypos, double width, double height) {
    	bounds = new Rectangle(xpos, ypos, width, height);
    }
    public double getWidth() {
    	return bounds.getWidth();
    }
    public double getHeight() {
    	return bounds.getHeight();
    }
    public double getXPos() {
    	return bounds.getX();
    }
    public double getYPos() {
    	return bounds.getY();    	
    }
}
