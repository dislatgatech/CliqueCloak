/*
 * Created on Dec 9, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator.MapUtils;

/**
 * @author Bugra Gedik
 *
 */
public class Point {
	private double x;
	private double y;
	
	public Point(Point p) {
		x = p.getX();
		y = p.getY();
	}
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}	
	public double distance(Point p) {
		return Math.sqrt( Math.pow(x-p.getX(), 2) + Math.pow(y-p.getY(), 2) );
	}
	public String toString() {
		return "("+x+","+y+")";
	}
}
