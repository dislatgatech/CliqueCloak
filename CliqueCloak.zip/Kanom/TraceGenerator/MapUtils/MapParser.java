/*
 * Created on Dec 9, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator.MapUtils;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.*;

import spatialindex.rtree.RTree;
import spatialindex.spatialindex.IData;
import spatialindex.spatialindex.INode;
import spatialindex.spatialindex.IVisitor;
import spatialindex.storagemanager.IStorageManager;
import spatialindex.storagemanager.MemoryStorageManager;
import spatialindex.storagemanager.PropertySet;


/**
 * @author Bugra Gedik
 *
 */
public class MapParser extends DefaultHandler{
	private Map map = null;
	
	public Map parse(InputStream is, String[] roadClassNames) {
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		saxParserFactory.setNamespaceAware(false);
		saxParserFactory.setValidating(false);
        
		try {
			saxParserFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		} catch(Exception e) {
			;//e.printStackTrace();
			//return null;
		}
        
		SAXParser saxParser = null;
		try{
			saxParser = saxParserFactory.newSAXParser();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
        
        map = new Map(roadClassNames);
		InputSource isrc = new InputSource(is);
		try {
			saxParser.parse(isrc, this);
		} catch (Exception e) {
            e.printStackTrace();
			map = null;
		}
		Map rmap = map;
		map = null;
		return rmap;
	}
	
	private int roadClassIndex = -1;
	private int currentSegmentId = 1;
	private RTree connectionIndex = null;
	private byte[] buffer = null;  
	
	public void startDocument() throws SAXException	{
		roadClassIndex = -1;
		currentSegmentId = 1;
		buffer = new byte[4];
		initConnectionIndex();
	}

	private void initConnectionIndex() {
		IStorageManager memoryfile = new MemoryStorageManager();
		// Create a new, empty, RTree with dimensionality 2, minimum load 70%, using "file" as
		// the StorageManager and the RSTAR splitting policy.
		PropertySet ps = new PropertySet();
		Double f = new Double(0.7);
		ps.setProperty("FillFactor", f);
		Integer i = new Integer(8);
		ps.setProperty("IndexCapacity", i);
		ps.setProperty("LeafCapacity", i);
		
		i = new Integer(2);
		ps.setProperty("Dimension", i);

		connectionIndex = new RTree(ps, memoryfile);
	}
	
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		String str = null;
		if(qName.equals("svg")) {
			if( null != (str = attributes.getValue("viewBox")) ) { 
				StringTokenizer st = new StringTokenizer(str);
				String[] values = {st.nextToken(), st.nextToken(), st.nextToken(), st.nextToken()};
				double x = Double.parseDouble(values[0]);
				double y = Double.parseDouble(values[1]);
				double w = Double.parseDouble(values[2]);
				double h = Double.parseDouble(values[3]);	
				map.setBounds(x, y, w, h);
			}
			return;
		}
		else if(qName.equals("g")) { 
			if( null != (str = attributes.getValue("id")) )  
				roadClassIndex = map.getRoadClassIndex(str);
			return;
		} 
		else if(qName.equals("polyline")) {
			if(roadClassIndex == -1) 
				return;
			if( null != (str = attributes.getValue("points")) ) {
				StringTokenizer st = new StringTokenizer(str);
				ArrayList al = new ArrayList();
				while(st.hasMoreTokens()) {
					String value = st.nextToken();
					int j = value.indexOf(',');
					double x = Double.parseDouble(value.substring(0, j));
					double y = Double.parseDouble(value.substring(j+1));
					al.add(new Point(x, y));
				}
				int n = al.size();
				Point[] points = new Point[n];
				for(int i=0; i<points.length; i++)
					points[i] = (Point) al.get(i);
				RoadSegment seg = new RoadSegment(currentSegmentId++ , roadClassIndex, points);
				map.addRoadSegment(seg);
				
				int id = seg.getId();
				Point segPoint = seg.getStartPoint();
				double[] segPoint_D = {segPoint.getX(), segPoint.getY()}; 
				spatialindex.spatialindex.Point segPoint_R = new spatialindex.spatialindex.Point(segPoint_D);
				connectionIndex.insertData(null, segPoint_R, id);
				
				segPoint = seg.getEndPoint();
				segPoint_D[0] = segPoint.getX();
				segPoint_D[1] = segPoint.getY();
				segPoint_R = new spatialindex.spatialindex.Point(segPoint_D);
				connectionIndex.insertData(null, segPoint_R, -id);
			}
		}
	}
   
    public void endElement(String uri, String localName, String qName) throws SAXException {
    	if(qName.equals("g"))
    		roadClassIndex = -1;
    }
    
    public void endDocument() throws SAXException	{      	
    	ConnIndexVisitor connVisitor = new ConnIndexVisitor();
    	
    	Iterator it = map.getSegmentIterator();
    	while(it.hasNext()) {
    		RoadSegment seg = (RoadSegment) it.next(); 
    		int segId = seg.getId();
    		
    		Point segPoint = seg.getStartPoint();
    		double[] segPoint_D = {segPoint.getX(), segPoint.getY()}; 
    		spatialindex.spatialindex.Point segPoint_R = new spatialindex.spatialindex.Point(segPoint_D);
    		connVisitor.clear();
    		connectionIndex.pointLocationQuery(segPoint_R, connVisitor);
    		ArrayList nbrList = connVisitor.getIds();
    		int[] nbrIds = new int[nbrList.size()-1];
    		for(int i=nbrList.size()-1, z=0; i>=0; i--) {
    			int nbrId = ((Integer)nbrList.get(i)).intValue();
    			if(nbrId != segId) 
    				nbrIds[z++] = nbrId;
    		}
    		seg.setStartNeighbors(nbrIds);
    		
    		segPoint = seg.getEndPoint();
    		segPoint_D[0] = segPoint.getX();
    		segPoint_D[1] = segPoint.getY();
    		segPoint_R = new spatialindex.spatialindex.Point(segPoint_D);
    		connVisitor.clear();
    		connectionIndex.pointLocationQuery(segPoint_R, connVisitor);
    		nbrList = connVisitor.getIds();
    		nbrIds = new int[nbrList.size()-1];
    		for(int i=nbrList.size()-1, z=0; i>=0; i--) {
    			int nbrId = ((Integer)nbrList.get(i)).intValue();
    			if(nbrId != -segId) 
    				nbrIds[z++] = nbrId;
    		}
    		seg.setEndNeighbors(nbrIds);
    		
    	}
    	connectionIndex = null;
    	System.gc();
    	
    }
    class ConnIndexVisitor implements IVisitor {
		private ArrayList ids = null;
    	public ConnIndexVisitor() {
    		ids = new ArrayList();
		}
    	public void clear() {
    		ids.clear();
    	}
    	public ArrayList getIds() {
    		return ids;
    	}
    	public void visitData(IData d) {
			int id = d.getIdentifier();
			ids.add(new Integer(id));
		}
		public void visitNode(INode n) {}
    	
    }
}
