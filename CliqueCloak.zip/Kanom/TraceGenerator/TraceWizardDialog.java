/*
 * Created on Dec 21, 2003
 */
package TraceGenerator;

import java.awt.*;
import java.awt.event.*;

import TraceGenerator.MessageBox;
import TraceGenerator.TraceUtils.TraceConf;

/**
 * @author Bugra Gedik
 */
public class TraceWizardDialog extends Dialog implements ActionListener, WindowListener, FocusListener {	
	private String[] roadClassNames = null;
	private double[] roadLengths = null;
	
	private boolean acceptStatus;
	
	public TraceWizardDialog(Frame parent, final String[] roadClassNames, final double[] roadLengths) {
		super(parent, "Trace Wizard", true);
		this.roadClassNames = roadClassNames;
		this.roadLengths = roadLengths;
		init();		
	}
	
	private void init() {
		java.awt.Point loc = getParent().getLocation();
		loc.x += 10; loc.y += 20;
		setLocation(loc);		

		BorderLayout layout = new BorderLayout();
		setLayout(layout);
		
		// bottom panel
		FlowLayout bottomPanelLayout = new FlowLayout(FlowLayout.RIGHT);
		bottomPanel = new Panel();
		bottomPanel.setLayout(bottomPanelLayout);
		nextButton = new Button("Next>>");
		cancelButton = new Button("Cancel");
		
		bottomPanel.add(cancelButton);
		bottomPanel.add(nextButton);
		
		// cneter panel
		centerPanel = new Panel();	
		
		add(bottomPanel, BorderLayout.SOUTH);
		add(centerPanel, BorderLayout.CENTER);
		
		nextButton.addActionListener(this);
		cancelButton.addActionListener(this);
		addWindowListener(this);
		
		setObjectPlacementSelectionScreen();
	}
	
	private void setObjectPlacementSelectionScreen() {
		setTitle("Select Trace Creation Type");
		centerPanel.removeAll();
		
		setResizable(true);
		setSize(2*150, 30*(2+1)+30);
		setResizable(false);		
		
		GridLayout centerPanelLayout = new GridLayout(2, 1);
		centerPanel.setLayout(centerPanelLayout);
		CheckboxGroup checkboxGroup = new CheckboxGroup();
		volumeCheckBox = new Checkbox("Use traffic volume data to create trace parameters", checkboxGroup, true);
		adHocCheckBox = new Checkbox("Use ad-hoc data to create trace parameters", checkboxGroup, false);
		
		centerPanel.add(volumeCheckBox);
		centerPanel.add(adHocCheckBox);
		validate();
	}
	
	private void setObjectPlacementScreen(boolean fromVolume) {		
		setTitle("Set Object Distribution Parameters");
		centerPanel.removeAll();
		
		roadLabelsHeader = new Label("Road Class Names");
		roadLabels = new Label[roadClassNames.length];
		for(int i=0; i<roadClassNames.length; i++)
			roadLabels[i] = new Label(roadClassNames[i]);
	
		if(fromVolume) {
			setResizable(true);
			setSize(2*150, 30*(roadClassNames.length+2)+30);
			setResizable(false);		
			
			GridLayout centerPanelLayout = new GridLayout(roadClassNames.length+1, 2);
			centerPanel.setLayout(centerPanelLayout);
			volumeFieldsHeader = new Label("Traffic Volume (cars/hour)");
			volumeFields = new TextField[roadClassNames.length];
			centerPanel.add(roadLabelsHeader);
			centerPanel.add(volumeFieldsHeader);
			for(int i=0; i<roadClassNames.length; i++) {
				volumeFields[i] = new TextField("0");
				volumeFields[i].addFocusListener(this);
				centerPanel.add(roadLabels[i]);
				centerPanel.add(volumeFields[i]);
			}
		}
		else {
			setResizable(true);
			setSize(2*150, 30*(roadClassNames.length+3)+30);
			setResizable(false);				

			GridLayout centerPanelLayout = new GridLayout(roadClassNames.length+2, 2);
			centerPanel.setLayout(centerPanelLayout);
			ratioFieldsHeader = new Label("Traffic Volume Ratio");
			ratioFields = new TextField[roadClassNames.length];
			centerPanel.add(roadLabelsHeader);
			centerPanel.add(ratioFieldsHeader);
			for(int i=0; i<roadClassNames.length; i++) {
				ratioFields[i] = new TextField(String.valueOf(roadLengths[i]));
				ratioFields[i].addFocusListener(this);
				centerPanel.add(roadLabels[i]);
				centerPanel.add(ratioFields[i]);
			}
			
			objectCountHeader = new Label("Number of Objects:");
			objectCountField = new TextField("0");
			objectCountField.addFocusListener(this);
			centerPanel.add(objectCountHeader);
			centerPanel.add(objectCountField);
		}
		validate();
	}	
	
	private void setObjectSpeedScreen() {
		setTitle("Set Object Speed and Related Parameters");
		centerPanel.removeAll();
		
		setResizable(true);
		setSize(3*150, 30*(roadClassNames.length+3)+30);
		setResizable(false);		
				
		GridLayout centerPanelLayout = new GridLayout(roadClassNames.length+2, 3);
		centerPanel.setLayout(centerPanelLayout);
		roadSpeedMeansHeader = new Label("Mean Speeds (km/h)");
		roadSpeedDevsHeader = new Label("Speeds Deviation(km/h)");
		speedMeanFields = new TextField[roadClassNames.length];
		speedDevnFields = new TextField[roadClassNames.length];
		centerPanel.add(roadLabelsHeader);
		centerPanel.add(roadSpeedMeansHeader);
		centerPanel.add(roadSpeedDevsHeader);
		for(int i=0; i<roadClassNames.length; i++) {
			speedMeanFields[i] = new TextField("0");
			speedMeanFields[i].addFocusListener(this);
			speedDevnFields[i] = new TextField("0");
			speedDevnFields[i].addFocusListener(this);
			centerPanel.add(roadLabels[i]);
			centerPanel.add(speedMeanFields[i]);
			centerPanel.add(speedDevnFields[i]);
		}		
		deltaHeader = new Label("Delta (m)");
		deltaField = new TextField("0");
		deltaField.addFocusListener(this);
		centerPanel.add(deltaHeader);
		centerPanel.add(deltaField);
		validate();
	}
	
	private Panel centerPanel = null;
	private Panel bottomPanel = null;
	private Button nextButton = null;
	private Button cancelButton = null;
	
	// object placement selection screen
	private Checkbox volumeCheckBox = null;
	private Checkbox adHocCheckBox = null;
	
    // object placement screen
	private Label roadLabelsHeader = null;
	private Label[] roadLabels = null;
    // object placement screen (volume)
	private Label volumeFieldsHeader = null;
	private TextField[] volumeFields = null;
	// object placement screen (ad-hoc)
	private Label ratioFieldsHeader = null;	
	private TextField[] ratioFields = null;
	private Label objectCountHeader = null;
	private TextField objectCountField = null;

	// object speed screen
	// private Label roadLabelsHeader = null;
	// private Label[] roadLabels = null;
	private Label roadSpeedMeansHeader = null;
	private Label roadSpeedDevsHeader = null;
	private TextField[] speedMeanFields = null;
	private TextField[] speedDevnFields = null;
	private Label deltaHeader = null;
	private TextField deltaField = null;
	
	private void checkTextFieldContent(TextField textField) {
		String fieldText = textField.getText();
		try{ 
			if(textField == objectCountField) 
				Integer.parseInt(fieldText);
			else 
				Double.parseDouble(fieldText);
		} catch(Exception e) {
			MessageBox mbox = new MessageBox("Error", "Invalid field", this);
			mbox.setVisible(true);
			textField.setText("0");
			textField.requestFocus();
		}			
	}
			
	public boolean getAcceptStatus () {
		return acceptStatus;
	}
	
	private TraceConf trace = null;
	private void finish() {
		acceptStatus = true;
        
        double[] objectSpeedMeans = new double[roadClassNames.length];
        double[] objectSpeedDevs = new double[roadClassNames.length]; 
        for(int i=0; i<roadClassNames.length; i++) {
	        objectSpeedMeans[i] = Double.parseDouble(speedMeanFields[i].getText()); 
	    	objectSpeedDevs[i] = Double.parseDouble(speedDevnFields[i].getText());
        }
        double delta = Double.parseDouble(deltaField.getText());			

        int numberOfObjects = 0; 
        double[] objectDistribution = new double[roadClassNames.length]; 
        if(adHocCheckBox.getState()) {
        	numberOfObjects = Integer.parseInt(objectCountField.getText());
        	double sum = 0;
        	for(int i=0; i<roadClassNames.length; i++) {
        		objectDistribution[i] = Double.parseDouble(ratioFields[i].getText());
        		sum = sum + objectDistribution[i];
        	}
        	for(int i=0; i<roadClassNames.length; i++)
        		objectDistribution[i] = objectDistribution[i] / sum; 
        } 
        else {
        	for(int i=0; i<roadClassNames.length; i++) {
        		double volume = Double.parseDouble(volumeFields[i].getText());
        		double indist = 1000 * (1/volume) * objectSpeedMeans[i];      
        		objectDistribution[i] = (int) Math.ceil( roadLengths[i] / indist );
        		numberOfObjects = numberOfObjects + (int) objectDistribution[i];
        	}
        	for(int i=0; i<roadClassNames.length; i++)
        		objectDistribution[i] = objectDistribution[i] / numberOfObjects;        	
        }        
		trace = new TraceConf(roadClassNames, numberOfObjects, objectDistribution, 
				          objectSpeedMeans, objectSpeedDevs, delta);
		setVisible(false);
	}
	
	public TraceConf getTrace() {
		return trace;
	}
	
	private void cancel() {
		acceptStatus = false;		
		trace = null;
		setVisible(false);
	}
	
	private int stage = 0;
	private void next() {
		stage = stage + 1;
		if(stage == 1)
			setObjectPlacementScreen(volumeCheckBox.getState());
		else if(stage == 2) {
			setObjectSpeedScreen();
			nextButton.setLabel("Finish");
		}
		else if(stage == 3)
			finish();
	}
	
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if(source == cancelButton)
			cancel();
		else if(source == nextButton) 
			next();
	}	
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowClosing(WindowEvent e) {cancel();}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}

	public void focusGained(FocusEvent e){}

	public void focusLost(FocusEvent e) {
		Object source = e.getSource();
		if(source instanceof TextField)
			checkTextFieldContent((TextField) source);
	}			
	
}
