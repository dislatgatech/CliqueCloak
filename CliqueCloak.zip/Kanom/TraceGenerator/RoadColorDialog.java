/*
 * Created on Dec 10, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator;

import java.awt.*;
import java.awt.event.*;

/**
 * @author Bugra Gedik
 *
 */
public class RoadColorDialog extends Dialog implements ActionListener, WindowListener{
	private Color[] colors = null;
	private String[] roadClassNames = null;
	protected static final Color[] defaultColors = {Color.BLUE, Color.RED, Color.GREEN, Color.ORANGE, Color.PINK, Color.YELLOW, Color.MAGENTA, Color.CYAN, Color.LIGHT_GRAY, Color.GRAY, Color.BLACK};
	protected static final String[] defaultColorNames = {"Blue", "Red", "Green", "Orange", "Pink", "Yellow", "Magenta", "Cyan", "Light Gray", "Gray", "Black"};
	private boolean acceptStatus;
	
	public RoadColorDialog(Frame parent, final String[] roadClassNames, final Color[] colors) {
		super(parent, "Adjust Map Road Colors", true);
		this.roadClassNames = roadClassNames;
		setColors(colors);
		init();
	}	
	
	private void init() {
		java.awt.Point loc = getParent().getLocation();
		loc.x += 10; loc.y += 20;
		setLocation(loc);		
		setSize(300, 30*(roadClassNames.length+1)+30);
		setResizable(false);
		
		BorderLayout layout = new BorderLayout();
		setLayout(layout);
		
		// bottom panel
		FlowLayout bottomPanelLayout = new FlowLayout(FlowLayout.RIGHT);
		bottomPanel = new Panel();
		bottomPanel.setLayout(bottomPanelLayout);
		okButton = new Button("  OK  ");
		cancelButton = new Button("Cancel");
		defaultsButton = new Button("Set to defaults");
		
		bottomPanel.add(defaultsButton);
		bottomPanel.add(cancelButton);
		bottomPanel.add(okButton);
		
        // center panel
		GridLayout centerPanelLayout = new GridLayout(roadClassNames.length, 2);
		centerPanel = new Panel();
		centerPanel.setLayout(centerPanelLayout);
		roadLabels = new Label[roadClassNames.length];
		colorButtons = new Button[roadClassNames.length];
		for(int i=0; i < roadClassNames.length; i++) {
			roadLabels[i] = new Label(" "+ roadClassNames[i] +" ");
			colorButtons[i] = new Button("Set Color");
			colorButtons[i].setBackground(colors[i]);
			colorButtons[i].addActionListener(this);
			centerPanel.add(roadLabels[i]);
			centerPanel.add(colorButtons[i]);
		}	
			
		add(bottomPanel, BorderLayout.SOUTH);
		add(centerPanel, BorderLayout.CENTER);
		
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
		defaultsButton.addActionListener(this);
		addWindowListener(this);
	}
	private Panel bottomPanel = null;
	private Panel centerPanel = null;
	private Button defaultsButton = null;
	private Button okButton = null;
	private Button cancelButton = null;
	private Label[] roadLabels = null;
	private Button[] colorButtons = null;
	
	public boolean getAcceptStatus () {
		return acceptStatus;
	}
	
	public Color[] getColors () {
		return colors;
	}
	
	private void setColors(Color[] ncolors) {
		Color[] tcolors = (ncolors!=null)?ncolors:defaultColors;
		colors = new Color[roadClassNames.length];
		for(int i=0; i<roadClassNames.length; i++) 
			colors[i] = tcolors[i%tcolors.length];
	}
	
	private void changeColor(int index) {
		ColorChooserDialog dialog = new ColorChooserDialog(this);
		dialog.setVisible(true);
		if(dialog.getAcceptStatus()) {
			Color ncolor = dialog.getColor();
			colorButtons[index].setBackground(ncolor);
			colors[index] = ncolor;
		}	
	}
	
	private void defaults() {
		setColors(null);
		updateButtonColors();
	}
	private void updateButtonColors(){
		for(int i=0; i<colors.length; i++)
			colorButtons[i].setBackground(colors[i]);
	}
	private void ok() {
		acceptStatus = true;
		setVisible(false);
	}
	
	private void cancel() {
		colors = null;
		acceptStatus = false;		
		setVisible(false);
	}
	
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if(source == cancelButton) 
			cancel();
		else if(source == okButton)
			ok();
		else if(source == defaultsButton)
			defaults();
		else if(source instanceof Button) {
			Button sbutton = (Button) source;
			for(int i=0; i<colorButtons.length; i++)
				if(colorButtons[i] == sbutton)
					changeColor(i);
		}
	}	
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowClosing(WindowEvent e) {cancel();}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}			
}

class ColorChooserDialog extends Dialog implements WindowListener, ActionListener, ItemListener, FocusListener{
    private Color color = null;
	private boolean acceptStatus;
    
	public ColorChooserDialog(Dialog parent) {
		super(parent, "", true);
		init();
	}
	public ColorChooserDialog(Frame parent) {
		super(parent, "", true);
		init();
	}
	
	private void init() {
		setTitle("Color Chooser");
		BorderLayout layout = new BorderLayout();
		setLayout(layout);
		
		bottomPanel = new Panel();
		FlowLayout bootomPanelLayout = new FlowLayout(FlowLayout.RIGHT);
		bottomPanel.setLayout(bootomPanelLayout);
		okButton = new Button("  OK  ");
		cancelButton = new Button("Cancel");
		bottomPanel.add(cancelButton);
		bottomPanel.add(okButton);	

		topPanel = new Panel();
		FlowLayout topPanelLayout = new FlowLayout(FlowLayout.CENTER);
		topPanel.setLayout(topPanelLayout);
		colorChoice = new Choice();
		for(int i=0; i<RoadColorDialog.defaultColors.length; i++)
			colorChoice.addItem(RoadColorDialog.defaultColorNames[i]);
		topPanel.add(colorChoice);
		redTextField = new TextField(3);
		greenTextField = new TextField(3);
		blueTextField = new TextField(3);
		topPanel.add(redTextField);
		topPanel.add(greenTextField);
		topPanel.add(blueTextField);
		
		colorLabel = new Label("");
		
		add(bottomPanel, BorderLayout.SOUTH);
		add(topPanel, BorderLayout.NORTH);
		add(colorLabel, BorderLayout.CENTER);
		
		color = RoadColorDialog.defaultColors[0];
		setVisuals();
		
		java.awt.Point loc = getParent().getLocation();
		loc.x += 10; loc.y += 20;
		setBounds(loc.x, loc.y, 250, 150);
		setResizable(false);
		
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
		colorChoice.addItemListener(this);
		redTextField.addFocusListener(this);
		greenTextField.addFocusListener(this);
		blueTextField.addFocusListener(this);
		addWindowListener(this);		
	}
	
	private Button okButton = null;
	private Button cancelButton = null;
	private Panel bottomPanel = null;
	private Panel topPanel = null;
	private Choice colorChoice = null;
	private Label colorLabel = null;
	private TextField redTextField =  null;
	private TextField greenTextField =  null;
	private TextField blueTextField =  null;
	
	private void setVisuals() {
		for(int i=0; i<RoadColorDialog.defaultColors.length; i++) {
			if( RoadColorDialog.defaultColors[i].equals(color) ) {
				colorChoice.select(i);
				break;
			}
		}
		int red = color.getRed();
		int green = color.getGreen();
		int blue = color.getBlue();
		redTextField.setText(String.valueOf(red));
		greenTextField.setText(String.valueOf(green));
		blueTextField.setText(String.valueOf(blue));
		colorLabel.setBackground(color);
	}
	
	private void colorChoiceChanged() {
		int index = colorChoice.getSelectedIndex();
		color = RoadColorDialog.defaultColors[index];
		setVisuals();
	}
	
	private void colorComponentChanged(TextField comp) {
		String text = comp.getText();
		int value;
		try {
			value = Integer.parseInt(text); 
		} catch(Exception e) {
			setVisuals();
			return;
		}
		if( value<0 || value >255 ) {
			setVisuals();
			return;
		}	
		if(comp == redTextField)
			color = new Color(value, color.getGreen(), color.getBlue());
		else if(comp == greenTextField)
			color = new Color(color.getRed(), value, color.getBlue());
		else if(comp == blueTextField)
			color = new Color(color.getRed(), color.getGreen(), value);
		setVisuals();
	}
	
	public Color getColor() {
		return color;
	}
	
	public boolean getAcceptStatus () {
		return acceptStatus;
	}
	
	private void cancel() {
		color = null;
		acceptStatus = false;
		setVisible(false);
	}
	
	private void ok() {
		acceptStatus = true;
		setVisible(false);
	}
	
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowClosing(WindowEvent e) {cancel();}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}
	
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if(source == okButton) 
			ok();
		else if(source == cancelButton)
			cancel();
	}

	public void itemStateChanged(ItemEvent event) {
		Object source = event.getSource();
		if(source == colorChoice) 
			colorChoiceChanged();
	}

	public void focusLost(FocusEvent event) {
		Object source = event.getSource();
		if(source == redTextField || source == greenTextField || source == blueTextField) 
			colorComponentChanged((TextField) source);
	}
	public void focusGained(FocusEvent e) {}
}
