/*
 * Created on Jan 3, 2004
 */
package TraceGenerator;

import java.awt.*;
import java.awt.event.*;

/**
 * @author Bugra Gedik
 */

class InputDialog extends Dialog implements WindowListener, ActionListener, FocusListener{
	public static final int BOOLEAN = 0;
	public static final int BYTE    = 1;
	public static final int INTEGER = 2;
	public static final int FLOAT   = 3;
	public static final int DOUBLE  = 4;
	public static final int STRING  = 5;
	
	private Button okButton = null;
	private Button cancelButton = null;
	private Label label = null;
	private TextField field = null; 
	private boolean acceptStatus = false;
	private int type = STRING;
	
	public InputDialog(String title, String message, Frame parent) {
		super(parent, title, true);
		init(title, message, parent); 
	}
	public InputDialog(String title, String message, Dialog parent) {
		super(parent, title, true);
		init(title, message, parent);
	}
	
	public void setType(int type) {
		this.type = type;
	}
	public int getType() {
		return type;
	}
	
	private void init(String title, String message, Window parent) {
		BorderLayout layout = new BorderLayout();
		setLayout(layout);
		
		label = new Label(message, Label.CENTER);
		add(label, BorderLayout.NORTH);
		field = new TextField("");
		add(field, BorderLayout.CENTER);
		
		okButton = new Button("  OK  ");
		cancelButton = new Button("Cancel");
		Panel panel = new Panel();
		FlowLayout panelLayout = new FlowLayout(FlowLayout.RIGHT); 
		panel.add(cancelButton);
		panel.add(okButton);
		add(panel, BorderLayout.SOUTH);
		
		java.awt.Point loc = getParent().getLocation();
		loc.x += 10; loc.y += 20;
		int width = label.getFontMetrics(label.getFont()).stringWidth(message) + 50;
		setBounds(loc.x, loc.y, width, 110);
		
		setResizable(false);
		
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
		field.addFocusListener(this);
		addWindowListener(this);		
	}
	public String getInput() {
		return field.getText();
	}
	public boolean getAcceptStatus() {
		return acceptStatus;
	}
	
	public void checkFieldValidity() {
		String str = field.getText();
		try{
			switch(type) {
			    case BOOLEAN: break;
			    case BYTE:    Byte.parseByte(str);     break;
			    case INTEGER: Integer.parseInt(str);   break;
			    case FLOAT:   Float.parseFloat(str);   break;
			    case DOUBLE:  Double.parseDouble(str); break;
			    case STRING:  break;
			}
		} catch(Exception e) {
			MessageBox mbox = new MessageBox("Error", "Invalid field", this);
			mbox.setVisible(true);
			field.setText("0");
			field.requestFocus();			
		}
	}
	
	private void accept() {
		acceptStatus = true;
		setVisible(false);		
	}
	private void cancel() {
		acceptStatus = false;
		setVisible(false);
	}
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowClosing(WindowEvent e) {cancel();}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if(source == okButton) 
			accept();
		else if(source == cancelButton)
			cancel();
	}
	
	public void focusGained(FocusEvent e) {}
	public void focusLost(FocusEvent e) {
		Object source = e.getSource();
		if(source == field)
			checkFieldValidity();
	}
}
