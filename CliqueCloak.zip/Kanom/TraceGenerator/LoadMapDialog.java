/*
 * Created on Dec 10, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FilenameFilter;
import java.util.StringTokenizer;


/**
 * @author Bugra Gedik
 *
 */
public class LoadMapDialog extends Dialog implements ActionListener, WindowListener, FilenameFilter {
	private String mapFilePath = null;
	private String[] roadClassNames = null;
	private boolean acceptStatus;
	
	public LoadMapDialog(Frame parent) {
		super(parent, "Load Map from Disk", true);
		init();
	}	
	private void init() {
		java.awt.Point loc = getParent().getLocation();
		loc.x += 10; loc.y += 20;
		setLocation(loc);
		setSize(300, 150);
		setResizable(false);
		
		BorderLayout layout = new BorderLayout();
		setLayout(layout);
		
		// bottom panel
		FlowLayout bottomPanelLayout = new FlowLayout(FlowLayout.RIGHT);
		bottomPanel = new Panel();
		bottomPanel.setLayout(bottomPanelLayout);
		okButton = new Button("  OK  ");
        cancelButton = new Button("Cancel");
        browseMapFileButton = new Button("Browse Map File ...");
        
        bottomPanel.add(browseMapFileButton);
        bottomPanel.add(cancelButton);
        bottomPanel.add(okButton);
        
		roadClassLabel = new Label("Please enter road class strings below");
		roadClassArea = new TextArea("CLASS_1 CLASS_2 CLASS_3 INTERCHANGE");
		
	
		add(bottomPanel, BorderLayout.SOUTH);
		add(roadClassLabel, BorderLayout.NORTH);
		add(roadClassArea, BorderLayout.CENTER);
		
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
		browseMapFileButton.addActionListener(this);
		addWindowListener(this);
	}
	private TextArea roadClassArea = null;
	private Label roadClassLabel = null;
	private Button browseMapFileButton = null;
	private Button okButton = null;
	private Button cancelButton = null;
	private Panel bottomPanel = null;
	
	public boolean getAcceptStatus () {
		return acceptStatus;
	}	
	public String getMapFilePath () {
		return mapFilePath;
	}
	public String[] getRoadClassNames () {
		return roadClassNames;
	}	
	
	private void setRoadClassNames() {
		String text = roadClassArea.getText();
		StringTokenizer st = new StringTokenizer(text);
		int n = st.countTokens();
		roadClassNames = new String[n];
		for(int i=0; st.hasMoreElements(); i++) {
			roadClassNames[i] = st.nextToken();
		}
	}
	
	private void browseFile() {
		FileDialog fd = new FileDialog((Frame) getParent(), "Select Map File ...");
		fd.setFilenameFilter(this);
		fd.setVisible(true);
		String file = fd.getFile();
		String dir = fd.getDirectory();
		if(file != null && dir != null) {
			mapFilePath = dir.concat(file);
		} 
	}

	public boolean accept(File dir, String name) {
		int index = name.lastIndexOf('.');
		if(index == -1) return false;
		String ext = name.substring(index+1);
		if(ext.equals("svg")) 
			return true;
		return false;
	}
	
	private void ok() {
		setRoadClassNames();
		if(mapFilePath == null) {
			MessageBox mbox = new MessageBox("Error", "No file selected", this);
			mbox.setVisible(true);
			return;
		}
		else if(roadClassNames.length == 0) {
			MessageBox mbox = new MessageBox("Error", "No road classes defined", this);
			mbox.setVisible(true);
			return;			
		}
		acceptStatus = true;
		setVisible(false);
	}
	
	private void cancel() {
		mapFilePath = null;
		roadClassNames = null;
		acceptStatus = false;		
		setVisible(false);
	}
	
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if(source == cancelButton) 
			cancel();
		else if(source == okButton)
			ok();
		else if(source == browseMapFileButton)
			browseFile();
		
	}	
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowClosing(WindowEvent e) {cancel();}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}
}
