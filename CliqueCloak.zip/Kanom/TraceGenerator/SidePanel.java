/*
 * Created on Dec 10, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import TraceGenerator.MainFrame.Document;
import TraceGenerator.TraceUtils.TraceConf;
import TraceGenerator.TraceUtils.TraceEngine;

/**
 * @author Bugra Gedik
 *
 */
public class SidePanel extends Panel implements ActionListener, FilenameFilter{
	private static final Dimension maximumSize = new Dimension(170, Integer.MAX_VALUE);
	
	private MainFrame mainFrame;
	public SidePanel(MainFrame mainFrame) {
		this.mainFrame = mainFrame;
		init();
	}
	private void init() {
		BorderLayout layout = new BorderLayout(); 
		setLayout(layout);
		setBackground(Color.GRAY);
		
		loadMapButton = new SButton("Load Map");
		setMapColorsButton = new SButton("Set Map Colors");
		configureTraceButton = new SButton("Configure Trace");
		saveTraceConfigurationButton  = new SButton("Save Trace Configuration");
		loadTraceConfigurationButton = new SButton("Load Trace Configuration");
		generateTraceButton = new SButton("Generate Trace");
		tracePanel = new TracePanel();
		
		Panel buttonPanel = new Panel();
		GridLayout buttonPanelLayout = new GridLayout(6, 1); 
		buttonPanel.setLayout(buttonPanelLayout);
		
		add(buttonPanel, BorderLayout.NORTH);
		buttonPanel.add(loadMapButton);
		buttonPanel.add(setMapColorsButton);
		buttonPanel.add(configureTraceButton);
		buttonPanel.add(saveTraceConfigurationButton);
		buttonPanel.add(loadTraceConfigurationButton);
		buttonPanel.add(generateTraceButton);
		add(tracePanel, BorderLayout.CENTER);
		
		loadMapButton.addActionListener(this);
		configureTraceButton.addActionListener(this);
		setMapColorsButton.addActionListener(this);
		loadTraceConfigurationButton.addActionListener(this);
		saveTraceConfigurationButton.addActionListener(this);
		generateTraceButton.addActionListener(this);
	}
	private Button loadMapButton = null;
	private Button setMapColorsButton = null;
	private Button configureTraceButton = null;
	private Button saveTraceConfigurationButton = null;
	private Button loadTraceConfigurationButton = null;
	private Button generateTraceButton = null;
	private TracePanel tracePanel = null;
	
	private void loadMapButtonEvent() {
		LoadMapDialog dialog = new LoadMapDialog(mainFrame);
		dialog.setVisible(true);
		Document doc = mainFrame.getDocument();
		if(dialog.getAcceptStatus()) {
			doc.mapPath = dialog.getMapFilePath();
			doc.roadClassNames = dialog.getRoadClassNames();
			mainFrame.loadMap();
			mainFrame.setTitle();
			mainFrame.displayMap();
			doc.trace = null;
			doc.tracePath = null;
			displayTrace();
		}		
	}
	
	private void configureTraceButtonEvent() {
		Document doc = mainFrame.getDocument();
		if(doc.map == null) {
			MessageBox mbox = new MessageBox("Error", "There is no map loaded", mainFrame);
			mbox.setVisible(true);
			return;
		}		
		TraceWizardDialog dialog = new TraceWizardDialog(mainFrame, doc.roadClassNames, doc.map.getRoadClassLengths());
		dialog.setVisible(true);
		if(dialog.getAcceptStatus()) {
			doc.trace = dialog.getTrace();
			mainFrame.setTitle();
			displayTrace();			
		}
	}
	
	private void loadTraceButtonEvent() {
		Document doc = mainFrame.getDocument();
		if(doc.map == null) {
			MessageBox mbox = new MessageBox("Error", "There is no map loaded", mainFrame);
			mbox.setVisible(true);
			return;			
		}
		FileDialog dialog = new FileDialog(mainFrame, "Define Trace Configuration File ...");
		dialog.setFilenameFilter(this);
		dialog.setVisible(true);
		String file = dialog.getFile();
		String dir = dialog.getDirectory();
		if(file != null && dir != null) {	
			String tracePath = dir.concat(file);
			try{
				TraceConf ltrace = TraceConf.fromFile(tracePath);
				doc.trace = ltrace; 
			} catch (IOException e) {
				MessageBox mbox = new MessageBox("Error", "Unable to load trace configuration", mainFrame);
				mbox.setVisible(true);				
				return;
			}
			doc.tracePath = tracePath;
			mainFrame.setTitle();
			displayTrace();
		}	
	}
	private void saveTraceButtonEvent() {
		Document doc = mainFrame.getDocument();
		if(doc.trace == null) {
			MessageBox mbox = new MessageBox("Error", "There is no trace configured", mainFrame);
			mbox.setVisible(true);
			return;			
		}

		FileDialog dialog = new FileDialog(mainFrame, "Define Trace FConfiguration ile ...");
		dialog.setMode(FileDialog.SAVE);
		dialog.setFilenameFilter(this);
		dialog.setVisible(true);
		String file = dialog.getFile();
		String dir = dialog.getDirectory();
		if(file != null && dir != null) {	
			String tracePath = dir.concat(file);
			try{
				TraceConf.toFile(tracePath, doc.trace);
			} catch (IOException e) {
				MessageBox mbox = new MessageBox("Error", "Unable to save trace", mainFrame);
				mbox.setVisible(true);
				return;
			}
			doc.tracePath = tracePath;
			mainFrame.setTitle();
		}	
	}
	
	public void generateTraceButtonEvent() {
		Document doc = mainFrame.getDocument();
		if(doc.trace == null) {
			MessageBox mbox = new MessageBox("Error", "There is no trace configured", mainFrame);
			mbox.setVisible(true);
			return;			
		}		
		
		FileDialog dialog = new FileDialog(mainFrame, "Define Trace Data File ...");
		dialog.setMode(FileDialog.SAVE);
		dialog.setVisible(true);
		String file = dialog.getFile();
		String dir = dialog.getDirectory();
		if(file != null && dir != null) {	
			try{
				InputDialog idialog = new InputDialog("Simulation Time", "Specify the duration of the simulation (in hours)", mainFrame);
				idialog.setType(InputDialog.DOUBLE);
				idialog.setVisible(true);
				if(idialog.getAcceptStatus()) { 
					double duration = Double.parseDouble(idialog.getInput());
					String path = dir.concat(file);
					FileOutputStream fw = new FileOutputStream(path);
					BufferedOutputStream bw = new BufferedOutputStream(fw);
					TraceEngine.generateTrace(doc.map, doc.trace, duration, bw);
					bw.flush(); bw.close(); 				
					TraceEngine.sortTraceDataFile(path, path);
				}
			} catch (IOException e) {
				MessageBox mbox = new MessageBox("Error", "Unable to generate trace", mainFrame);
				mbox.setVisible(true);
				e.printStackTrace();
				return;
			}
		}
		
	}
	
	public boolean accept(File dir, String name) {
		int index = name.lastIndexOf('.');
		if(index == -1) return false;
		String ext = name.substring(index+1);
		if(ext.equals("trc")) 
			return true;
		return false;
	}
		
	private void displayTrace() {
		Document doc = mainFrame.getDocument();
		tracePanel.setTrace(doc.trace);
		tracePanel.repaint();
	}

	private void setMapColorsButtonEvent() {
		Document doc = mainFrame.getDocument();
		if(doc.map == null) {
			MessageBox mbox = new MessageBox("Error", "Map is not loaded", mainFrame);
			mbox.setVisible(true);
			return;
		}
		RoadColorDialog dialog = new RoadColorDialog(mainFrame, doc.roadClassNames, doc.roadClassColors);
		dialog.setVisible(true);
		if(dialog.getAcceptStatus()) {
			doc.roadClassColors = dialog.getColors();
			mainFrame.displayMap();
		}			
	}
	
	public Dimension getPreferredSize() {
		Dimension pd = getParent().getSize();
		pd.width = maximumSize.width;
		return pd;
	}	
	
	private static final int idealSButtonHeight = 30;
	private static final int idealSButtonWidth = 160;
	class SButton extends Button {	
		public SButton(String str) {
			super(str);
		}
		public Dimension getPreferredSize() {
			Dimension pd = getParent().getSize();
			pd.height = idealSButtonHeight;
			pd.width = idealSButtonWidth;
			return pd;
		}		
	}

	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if(source == loadMapButton)
            loadMapButtonEvent();  
		else if(source == setMapColorsButton)
			setMapColorsButtonEvent();
		else if(source == configureTraceButton)
			configureTraceButtonEvent();
		else if(source == loadTraceConfigurationButton)
			loadTraceButtonEvent();
		else if(source == saveTraceConfigurationButton)
			saveTraceButtonEvent();
		else if(source == generateTraceButton)
			generateTraceButtonEvent();
	}
}


