/*
 * Created on Dec 26, 2003
 */
package TraceGenerator;

import java.awt.*;
import java.awt.event.*;

/**
 * @author Bugra Gedik
 */

class MessageBox extends Dialog implements WindowListener, ActionListener{
	private Button okButton = null;
	private Label label = null;
	public MessageBox(String title, String message, Frame parent) {
		super(parent, title, true);
		init(title, message, parent);
	}
	public MessageBox(String title, String message, Dialog parent) {
		super(parent, title, true);
		init(title, message, parent);
	}
	private void init(String title, String message, Window parent) {
		BorderLayout layout = new BorderLayout();
		setLayout(layout);
		
		label = new Label(message, Label.CENTER);
		add(label, BorderLayout.CENTER);
		okButton = new Button("OK");
		add(okButton, BorderLayout.SOUTH);
		
		java.awt.Point loc = getParent().getLocation();
		loc.x += 10; loc.y += 20;
		int width = label.getFontMetrics(label.getFont()).stringWidth(message) + 50;
		setBounds(loc.x, loc.y, width, 100);
		okButton.addActionListener(this);
		addWindowListener(this);		
	}
	private void close() {
		setVisible(false);
	}
	public void windowActivated(WindowEvent e) {}
	public void windowClosed(WindowEvent e) {}
	public void windowClosing(WindowEvent e) {close();}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}
	public void actionPerformed(ActionEvent event) {
		Object source = event.getSource();
		if(source == okButton) close();
	}
}
