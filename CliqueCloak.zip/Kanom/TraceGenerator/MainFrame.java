/*
 * Created on Dec 10, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

import TraceGenerator.MapUtils.*;
import TraceGenerator.TraceUtils.*;

/**
 * @author Bugra Gedik
 *
 */
public class MainFrame extends Frame implements WindowListener{
	private Document doc = null;
	private MapParser mapParser = null;
	
	public MainFrame() {
	    doc	= new Document();
	    mapParser = new MapParser();
		initVisuals();	
	}
	private void initVisuals() {
        setTitle();
		setBounds(10, 10, 750, 750);
		
		BorderLayout layout = new BorderLayout(0, 0);
		setLayout(layout);
		
		sidePanel = new SidePanel(this);
		mapPanel = new MapPanel();
		
		add(mapPanel, BorderLayout.CENTER);
		add(sidePanel, BorderLayout.EAST);
		
		addWindowListener(this);
	}
	private SidePanel sidePanel = null;
	private MapPanel mapPanel = null;
	
	private String currentMapPath = null;
	private String currentTracePath = null;
	
	 
	public void setTitle() {
		if(doc.trace == null || doc.tracePath != null)
			setTitle("Trace Generator, Current Map = " + doc.mapPath+ ", Current Trace = " + doc.tracePath);
		else
			setTitle("Trace Generator, Current Map = " + doc.mapPath+ ", Current Trace = new trace");
	}
	
	protected void loadMap() {
		BufferedInputStream bs = null;
		FileInputStream fs = null;
		try{
			fs = new FileInputStream(doc.mapPath);
			bs = new BufferedInputStream(fs);
		}catch(IOException e) {
			e.printStackTrace();
			MessageBox mbox = new MessageBox("Error", "Unable to Open Map File", this);
			mbox.setVisible(true);
		}
		doc.map = mapParser.parse(bs, doc.roadClassNames);
		if(doc.map == null) {
			MessageBox mbox = new MessageBox("Error", "Unable to Load Map", this);
			mbox.setVisible(true);				
		}
	}
	
	protected void displayMap() {
	    mapPanel.setMap(doc.map);
	    mapPanel.setRoadClassColors(doc.roadClassColors);
		mapPanel.repaint();
	}
	
	protected Document getDocument() {
		return doc;
	}
	
	class Document {
		Map map = null;
		String mapPath = null; 
		TraceConf trace = null;
		String tracePath = null;
		
		Color[] roadClassColors = null;
		String[] roadClassNames = null;		
	}
	
///////////////////////////////////////////////////////////	
	public void windowClosed(WindowEvent e) {}
	public void windowActivated(WindowEvent e) {}
	public void windowClosing(WindowEvent e) {
		System.exit(0);
	}
	public void windowDeactivated(WindowEvent e) {}
	public void windowDeiconified(WindowEvent e) {}
	public void windowIconified(WindowEvent e) {}
	public void windowOpened(WindowEvent e) {}
}
