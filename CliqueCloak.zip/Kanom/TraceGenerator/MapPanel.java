/*
 * Created on Dec 10, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package TraceGenerator;

import java.awt.*;
import java.util.Iterator;

import TraceGenerator.MapUtils.*;
import TraceGenerator.MapUtils.Point;

/**
 * @author Bugra Gedik
 *
 */
public class MapPanel extends Component{
	private Map map;
	private Image buffer = null;
	private Graphics bgraphics = null;
	
	private Color[] roadClassColors = null;
	
	public MapPanel() {}
	
	public void setMap(final Map map) {
		this.map = map;
	}
	
	public void paint(Graphics g) {
		java.awt.Rectangle bounds = getBounds();
		double width = bounds.getWidth();
		double height = bounds.getHeight();
		
		if(buffer == null || 
			buffer.getWidth(null) != (int) width ||
			buffer.getHeight(null) != (int) height) {
			buffer = createImage((int) width, (int) height);
			if(buffer != null) 
				bgraphics = buffer.getGraphics();
		} 
		
		if(buffer == null) { 
			super.paint(g);
			return;
		} 
		
		// print on buffer
		bgraphics.clearRect(0, 0, (int) width, (int) height);
		if(map != null) {
			double rx = map.getXPos(), ry = map.getYPos();
			double rs = Math.min(width/map.getWidth(), height/map.getHeight());
			Iterator it = map.getSegmentIterator();
			while(it.hasNext()) {
				RoadSegment seg = (RoadSegment) it.next();
				int roadClassIndex = seg.getRoadClassIndex();
				if(roadClassColors == null || roadClassColors.length <= roadClassIndex) 
					bgraphics.setColor(Color.BLACK);				
				else 
					bgraphics.setColor(roadClassColors[roadClassIndex]);
			
				int n = seg.getNumberOfPoints();
				Point s = seg.getPointAt(0), e = null;
				for(int i=1; i<n; i++) {
					e = seg.getPointAt(i);
					double x1 = (s.getX() - rx) * rs, y1 = height - ( (s.getY() - ry) * rs );
					double x2 = (e.getX() - rx) * rs, y2 = height - ( (e.getY() - ry) * rs );
					bgraphics.drawLine((int) x1, (int) y1, (int) x2, (int) y2);
					s = e;
				}
			}
		}
		g.drawImage(buffer, 0, 0, null);
	}
	public void setRoadClassColors(Color[] roadClassColors) {
		this.roadClassColors = roadClassColors;
	}
	
	public boolean isDoubleBuffered() {
		return true;
	}
}
