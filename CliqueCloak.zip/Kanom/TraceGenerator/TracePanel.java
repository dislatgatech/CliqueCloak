/*
 * Created on Dec 23, 2003
 */
package TraceGenerator;

import java.awt.*;
import java.util.StringTokenizer;

import TraceGenerator.TraceUtils.*;

/**
 * @author Bugra Gedik
 */
public class TracePanel extends Component {
	private TraceConf trace = null;
	
	public TracePanel(){}
	
	public void setTrace(TraceConf trace) {
		this.trace = trace;
	}
	
	public void paint(Graphics g) {
		int width = getWidth();
		int height = getHeight();
		g.setColor(Color.WHITE);
		g.fill3DRect(2, 2, width-4, height-4, true);
		g.setColor(Color.BLACK);
		StringBuffer sbuff = new StringBuffer();
		sbuff.append("Trace Parameters\n");
		sbuff.append("----------------\n");
		if(trace == null) {
			sbuff.append("# of objs.: N/A\n");
			sbuff.append("obj. distributions: N/A\n");
			sbuff.append("delta: N/A\n");
		}
		else {
			sbuff.append("# of objs.: "+trace.getNumberOfObjects()+"\n");
			sbuff.append("obj. distributions:\n");
			String[] roadClassNames = trace.getRoadClassNames();
			double[] objectDistribution  = trace.getObjectDistribution();
			double[] objectSpeedMeans = trace.getObjectSpeedMeans();
			double[] objectSpeedDevs = trace.getObjectSpeedDevs();
			for(int i=0; i<roadClassNames.length; i++) {
				sbuff.append(
					"* "+roadClassNames[i]+": \n"+
					" - "+objectDistribution[i]+"\n"+
					" - "+objectSpeedMeans[i]+"km/h\n"+
					" - "+objectSpeedDevs[i]+"km/h\n"
		    	);
			}
			sbuff.append("delta: "+trace.getDelta()+"m\n");
		}
		StringTokenizer stok = new StringTokenizer(sbuff.toString(), "\n");
		FontMetrics fontMetrics = g.getFontMetrics();
		int xpos = 5;
		int ypos = xpos + fontMetrics.getHeight();
		
		while(stok.hasMoreTokens()) {
			String token = stok.nextToken();
			g.drawString(token ,xpos, ypos);
			ypos += fontMetrics.getHeight();
		}
	}
	
}
