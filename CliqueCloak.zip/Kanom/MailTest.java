import java.security.Security;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/*
 * Created on Jan 10, 2005
 */

/**
 * @author Bugra
 */

class SMTPAuthenticator extends javax.mail.Authenticator {

    public PasswordAuthentication getPasswordAuthentication() {
      return new PasswordAuthentication("no-reply@inciminci.com", "enigma"); 
    }
}

public class MailTest {
    public static void main(String[] args) {
        Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
        SecurityManager security = System.getSecurityManager();
        System.out.println("Security Manager: " + security);
        
        Properties p = new Properties();
        p.put("mail.smtp.user", "no-reply@inciminci.com");
        p.put("mail.smtp.host", "smtp.gmail.com");
        p.put("mail.smtp.port", "465");
        p.put("mail.smtp.auth", "true"); 
        p.put("mail.smtp.ssl", "true");
        p.put("mail.smtp.starttls.enable","true");
        p.put("mail.smtp.debug", "true");
        
        p.put("mail.smtp.socketFactory.port", "465"); 
        p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        p.put("mail.smtp.socketFactory.fallback", "false");

        try {
          Authenticator auth = new SMTPAuthenticator();
          Session session = Session.getInstance(p, auth);
          session.setDebug(true);

          MimeMessage msg = new MimeMessage(session);
          msg.setText("Olay bazinda degerligin kac senin, JavaMail'den");
          msg.setSubject("Olayin ne senin?");
          Address fromAddr = new InternetAddress("no-reply@inciminci.com");
          msg.setFrom(fromAddr);
          Address toAddr = new InternetAddress("seyhmus@gmail.com");
          msg.addRecipient(Message.RecipientType.TO, toAddr);
          System.out.println("Message: " + msg.getContent());
          Transport.send(msg);
        } catch (Exception mex) { // Prints all nested (chained) exceptions as well
          mex.printStackTrace();
        }
    }    
}

/*
try {
    String smtpHost = "lennon.cc.gatech.edu";
    String from = "beorn@cc.gatech.edu"; 
    String to = "bgedik@gmail.com"; 
    String bcc = "bgedik@cc.gatech.edu";
    String subject = "Re: ";
    String body = "Aklin ermez mapusluga, bahcede sari isiga. " +
            "13 tane yas dokuldu ranzandaki yastigina. " +
            "Buyudun yavrum sen de. Hasret sende sevgi bende. " +
            "Aksamlar doner geceye, geceler gene gunduze.";
    
    // Get system properties
    Properties props = System.getProperties();

    // Setup mail server
    props.put("mail.smtp.host", smtpHost);

    // Get session
    Session session = Session.getDefaultInstance(props, null);

    // Define message
    MimeMessage message = new MimeMessage(session);
    message.setFrom(new InternetAddress(from));
    message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
    message.addRecipient(Message.RecipientType.BCC, new InternetAddress(bcc));
    message.setSubject(subject);
    message.setText(body);

    // Send message
    Transport.send(message);    

} catch(Exception e) {
    e.printStackTrace();
}
*/
