package utils;
/*
 * Created on May 6, 2003
 *
 * Bugra Gedik
 * IBM T.J. Watson Research Center
 */
/**
 * @author bgedik: Bugra Gedik
 */
public final class Zipf {
    private double zp;
    private int n;
    private double p[]; 
    public Zipf(double zp, int n){
        this.zp = zp;
        this.n = n;
        p = new double[n];
        init();
    }
    private void init(){
        double sum = 0;
        for (int i=0; i<n; i++){
            p[i] = 1/Math.pow(i+1, zp);
            sum = sum + p[i];
        }
        for (int i=0; i<n; i++)
            p[i] = p[i]/sum;
        for (int i=1; i<n; i++)
            p[i] = p[i] + p[i-1];
    }
    
    public double getMean(double[] vals) {
        double mean = vals[0]*p[0];
        for (int i=1; i<n; i++)
            mean += (p[i]-p[i-1])*vals[i];
        return mean;
    }
        
    public int getRandomValue(){
        double v = Math.random();
        for(int i=0; i<n; i++){
            if(v<p[i])
                return i;
        }    
        return 0;
    } 
}
