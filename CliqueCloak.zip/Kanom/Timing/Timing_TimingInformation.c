/*
 * An implementation of JNI methods in Timing.TimingInformation class.
 *
 * Author: Bugra Gedik, based on Vladimir Roubtsov's code 
*/


#include "Timing_TimingInformation.h"

#include <unistd.h>
#include <sys/times.h>
#include <limits.h>


static jint s_PID;
static int s_numberOfProcessors;
static long s_ticksPerSecond;

/*
 * This method was added in JNI 1.2. It is executed once before any other
 * methods are called and is ostensibly for negotiating JNI spec versions,
 * but can also be conveniently used for initializing variables that will
 * not change throughout the lifetime of this process.
*/
 JNIEXPORT jint JNICALL JNI_OnLoad (JavaVM * vm, void * reserved) {
    s_PID = (jint) getpid ();
    s_numberOfProcessors = sysconf(_SC_NPROCESSORS_ONLN);
    s_ticksPerSecond = sysconf(_SC_CLK_TCK); 

    return JNI_VERSION_1_2;
}


/*
 * Class:     Timing_TimingInformation
 * Method:    getProcessID
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_Timing_TimingInformation_getProcessID (JNIEnv * vm, jclass cl) {
    return s_PID;
}

/*
 * Class:     Timing_TimingInformation
 * Method:    getProcessCPUTime
 * Signature: ()J
 */
JNIEXPORT jlong JNICALL Java_Timing_TimingInformation_getProcessCPUTime (JNIEnv * vm, jclass cl) {
    struct tms time_taken; 
    long total_time_in_millis;
    s_numberOfProcessors = 1;
    times(&time_taken);
    total_time_in_millis = ((time_taken.tms_cutime + time_taken.tms_cstime) * 1000) / s_ticksPerSecond;
    return (jlong) ( total_time_in_millis / s_numberOfProcessors );
}
 
