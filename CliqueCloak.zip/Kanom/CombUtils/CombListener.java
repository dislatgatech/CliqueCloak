/*
 * Created on Nov 29, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package CombUtils;

/**
 * @author Golgeliyele
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public interface CombListener {
	public boolean combEvent(int[] event);
}
