/*
 * Created on Oct 23, 2003
 *
 */
package CombUtils;

import java.util.Arrays;

/**
 * @author Bugra Gedik
 */
public class CombUtils {
	
	
	private static int[] c = null;
	public static int perms(boolean init, int k, int[] p) {
		if(init) {
			c = new int[k];
			for(int i=0; i<k; i++)
				c[i] = 0;
			c[0] = 1;
			c[k-1] = -1;
			return 1;
		}
        // if all permutations are generated
		if(c[0] == k) return -1;
        
        int i = k-1;
        while(++c[i] == i+1) {
        	c[i--] = 0;
        	c[0]--;
        }
        if(c[i]==i) c[0]++;
        
        for(i=0; i<k; i++)
        	p[i] = i;
        for(i=k-1; i>0; i--) {
        	int temp = p[i]; 
        	p[i] = p[c[i]];
        	p[c[i]] = temp;
        }
        return 0;
	}
	
	
	public static void generateCombinations(int n, int k, CombListener ls) { 
		if(k<0 || k>n) return;
		int[] cs = new int[k]; 
		gencomb(n, k, 0, cs, ls);
	}
	private static boolean gencomb(int n, int k, int l, int[] cs, CombListener ls) {
		if(l==k)  
		    return ls.combEvent(cs);
		
		int last = (l==0)?-1:cs[l-1];
		int remn = k-l; 
		for(int i=last+1; i<n; i++) {
			if(n-i < remn) break;
			cs[l] = i;
			boolean stop =
			gencomb(n, k, l+1, cs, ls);
			if(stop) return true;
		}
		return false;
	}
	
	public static void generatePermutations(int n, int k, CombListener ls) { 
		if(k<0 || k>n) return;
		int[] cs = new int[k]; 
		genperm(n, k, 0, cs, ls);
	}
	private static boolean genperm(int n, int k, int l, int[] cs, CombListener ls) {
		if(l==k) 
			return ls.combEvent(cs);
		
		int[] ds = new int[l+1]; ds[l] = n;
		System.arraycopy(cs, 0, ds, 0, l);
		Arrays.sort(ds, 0, l); 
		int b = 0; 
		for(int i=0; i<=l; i++) {
			int f = ds[i];
			for(int j=b; j<f; j++) {
				cs[l] = j;
				boolean stop = 
				genperm(n, k, l+1, cs, ls);
				if(stop) return true;
			}
			b = f + 1;
		}
		return false;
	}	
	

	public static void subsets(int n, CombListener ls){
		for(int i=0; i<=n; i++)
			generateCombinations(n, i, ls);
	}
	public static void sublists(int n, CombListener ls) {
		for (int i = 0; i <= n; i++)
			generatePermutations(n, i, ls);
	}	
	
	public static void main(String args[]) {
        int n = 4, k = 2;
        CombPrinter cp = new CombPrinter();
        /*
		generatePermutations(n, k, cp);
	
		System.out.println();
				
		int[] p = new int[k];
		perms(true, k, p);
		while(-1 != perms(false, k, p)) {
			System.out.print("{");
			for(int i=0; i<k; i++)
				System.out.print(p[i]+((i!=k-1)?" ":""));
			System.out.println("}");
		}
*/		
		cp = new CombPrinter();
		generateCombinations(n, k, cp);		
	}
}

class CombPrinter implements CombListener{
	public boolean combEvent(int[] event) {
		System.out.print("{");
		int l = event.length;
		for(int i=0; i<l; i++)
			System.out.print(event[i]+((i!=l-1)?" ":""));
		System.out.println("}");
		return false;
	}
}
