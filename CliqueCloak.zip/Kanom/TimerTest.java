/*
 * Created on Feb 7, 2005
 *
 */

/**
 * @author Bugra
 *
 */

import com.vladium.utils.timing.HRTimer;

public class TimerTest {

    public static void main(String[] args) {
        double time, p_time;
        
        for(int i=0; i<15; ++i) {
            time = p_time = HRTimer.getTime();
            while((time=HRTimer.getTime())==p_time);
            System.err.println((time-p_time)+"ms");
        }  
        
    }
}
