/*
 * Created on Dec 6, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

/**
 * @author Bugra Gedik
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
//import java.awt.*;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.util.Iterator;

//import BGGraph.*;
import TraceGenerator.*;
//import TraceGenerator.MapUtils.*;

public class Test {

	public static void main(String[] args) {
		
		MainFrame mf = new MainFrame();
		mf.setVisible(true);		
/*		
		String[] rnames = {"CLASS_1", "CLASS_2", "CLASS_3", "INTERCHANGE"};	
		FileInputStream fs = null;
		try{
			fs = new FileInputStream("svg.svg");
		}catch(IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		MapParser mp = new MapParser();
		Map map = mp.parse(fs, rnames);
		int z = 0;
		Iterator it = map.getSegmentIterator();
		while(it.hasNext()) {
			boolean lone = true;
			RoadSegment seg = (RoadSegment) it.next();
			System.err.println(seg.getId()+":");
			int[] nbrIds = seg.getStartNeighbors();
			for(int i=0; i<nbrIds.length; i++) 
				System.err.print( ((i==0)?"\ts) ":"") + nbrIds[i] + " ");
			if(nbrIds.length!=0) System.err.println();
			lone = (nbrIds.length==0);
			
			nbrIds = seg.getEndNeighbors();
			for(int i=0; i<nbrIds.length; i++) 
				System.err.print( ((i==0)?"\te) ":"") + nbrIds[i] + " ");
			lone = lone & (nbrIds.length==0);
			if(nbrIds.length!=0) System.err.println();
			if(!lone) z++;
		}
		System.out.println(z+"/"+map.getNumberOfRoadSegments());
		System.exit(0);
		
		Frame frame = new Frame("MapViewer Test");
		MapPanel mpan = new MapPanel();
		mpan.setMap(map);
		Color[] colors = {Color.BLUE, Color.RED, Color.GREEN};
		mpan.setRoadClassColors(colors);
		frame.add(mpan);
		frame.setBounds(10, 10, 400, 400);
		frame.setVisible(true);
		try {
			Thread.sleep(10000);
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.exit(0);
		
		try{
			fs = new FileInputStream("x.txt");
		}catch(IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		DynDGraph dgraph = new DynDGraph();
		dgraph.read(fs);
		dgraph.write(System.out);
		System.out.println(dgraph.getNumberOfEdges());
		System.out.println(dgraph.getNumberOfNodes());

		System.out.println();
				
		try{
			fs = new FileInputStream("y.txt");
		}catch(IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		DynUGraph ugraph = new DynUGraph();
		ugraph.read(fs);
		ugraph.write(System.out);
		System.out.println(ugraph.getNumberOfEdges());
		System.out.println(ugraph.getNumberOfNodes());
		System.out.println();
				
		ugraph.removeEdge(0, 0);
		ugraph.addEdge(4, 4, 1.5);
		ugraph.removeEdge(3, 8);
		ugraph.write(System.out);
		System.out.println(ugraph.getNumberOfEdges());
		System.out.println(ugraph.getNumberOfNodes());
		
		int[] ids = ugraph.getNodeIds();
		for(int i=0; i<ids.length; i++) 
			System.out.print("{"+ids[i]+","+ugraph.getNumberOfNeighbors(ids[i])+"} ");
		System.out.println();	
*/
	}
}
