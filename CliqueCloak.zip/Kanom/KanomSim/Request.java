/*
 * Created on Jan 14, 2004
 */
package KanomSim;

import spatialindex.spatialindex.Point;
import spatialindex.spatialindex.Region;

/**
 * @author Bugra Gedik
 */
public class Request implements Comparable{
    private int id;
    private int k;
    private double t, dt;
    private double x, dx;
    private double y, dy;
    
    public Request(int id, int k, double t, double dt, double x, double dx, double y, double dy) {
        this.id = id; this.k = k;
        this.t = t;	this.dt = dt;
        this.x = x;	this.dx = dx;
        this.y = y;	this.dy = dy;
    }
    public int getK() { return k; }
    public int getId() { return id; }
    public double getT() { return t; }
    public double getDT() { return dt; }
    public double getX() { return x; }
    public double getDX() { return dx; }
    public double getY() { return y; }
    public double getDY() { return dy; }
    public double getDeadLine() { return t + dt; }
    
    public Point getPoint() {
        double[] point = {t, x, y};
        return new Point(point);
    }
    public Point getSPoint() {
        double[] point = {x, y};
        return new Point(point);
    }
    public Region getRegion() {
        double[] low = new double[3];
        double[] high = new double[3];
        low[0] = t - dt;
        low[1] = x - dx; 
        low[2] = y - dy;
        high[0] = t + dt;
        high[1] = x + dx; 
        high[2] = y + dy;
        return new Region(low, high);
    }
    public Region getSRegion() {
        double[] low = new double[2];
        double[] high = new double[2];
        low[0] = x - dx; 
        low[1] = y - dy;
        high[0] = x + dx; 
        high[1] = y + dy;
        return new Region(low, high);
    }
    
    public String toString() {
        return "["+id+":"+"k:"+k+", t:("+t+","+dt+")"+", x:("+x+","+dx+")"+", y:("+y+","+dy+")]"; 
    }
        
    public int compareTo(Object obj) {
        Request req = (Request) obj;
        double mdline = getDeadLine();
        double odline = req.getDeadLine();
        if(mdline < odline) 
            return -1;
        else if (mdline > odline)
            return 1;
        else if(t < req.t)		return -1;
        else if(t > req.t)		return 1;
        else if(id < req.id) 	return -1;
        else if(id > req.id)	return 1;
        else if(k < req.k)		return -1;
        else if(k > req.k)		return 1;
        else if(x < req.x)		return -1;
        else if(x > req.x)		return 1;
        else if(y < req.y)		return -1;
        else if(y > req.y)		return 1;
        else if(dx < req.dx)	return -1;
        else if(dx > req.dx)	return 1;
        else if(dy < req.dy)	return -1;
        else if(dy > req.dy)	return 1;
        return 0;     
    }
    public boolean equals(Object obj) {
        Request req = (Request) obj;
        if(id != req.id || k!= req.k) return false;
        if(t != req.t || dt!= req.dt) return false;
        if(x != req.x || dx!= req.dx) return false;
        if(y != req.y || dy!= req.dy) return false;
        return true;
    }
}

