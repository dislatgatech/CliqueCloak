/*
 * Created on Jan 12, 2004
 */
package KanomSim;

import java.io.IOException;
import java.util.HashMap;
import java.util.Random;

import TraceGenerator.TraceUtils.PosRecord;
import TraceGenerator.TraceUtils.TraceReader;

/**
 * @author Bugra Gedik
 */
public class RequestGenerator {
    private RequestParamGenerator paramGen = null;
    private TraceReader traceReader = null;
    private double mint;
    private double vint;
    private Random rand = null;
    
    public RequestGenerator(RequestParamGenerator paramGen, TraceReader traceReader, 
							double mint, double vint) {
        this.paramGen = paramGen;
        this.traceReader = traceReader;
        this.mint = mint;
        this.vint = vint;
    }
    
    public RequestParamGenerator getRequestParamGenerator() {
        return paramGen;
    }
    public TraceReader getTraceReader() {
        return traceReader;
    }
    public double getIATMean() {
        return this.mint;
    }
    public double getIATVar() {
        return this.vint;
    }    
    
    
    private HashMap blockedMap = null;
    private HashMap timeMap = null;
    
    public void init() throws IOException {
        traceReader.open();
        blockedMap = new HashMap();
        timeMap = new HashMap();
        rand = new Random();
    }
    
    public boolean releaseObject(int oid) {
        Integer ID = new Integer(oid);
        Boolean blocked = (Boolean) blockedMap.get(ID);
        if(blocked == null || blocked == Boolean.FALSE)
            return false;
        blockedMap.put(ID, Boolean.FALSE);
        return true;
    }
    
    public Request nextRequest() throws IOException{
        while(true) {
            PosRecord prec = traceReader.next();
            if(prec == null)
            	return null;
        
            Integer ID = new Integer(prec.getId());
            Boolean blocked = (Boolean) blockedMap.get(ID);
            if(blocked != null && blocked == Boolean.TRUE)
                continue;
            
            Double ntime = (Double) timeMap.get(ID);            
            if(ntime != null && prec.getT()*3600 < ntime.doubleValue())
                continue;
            
            ntime = new Double( prec.getT()*3600 + Math.abs(mint + Math.sqrt(vint)*rand.nextGaussian()) ); 
            timeMap.put(ID, ntime);
            if(blocked == null) {
                blockedMap.put(ID, Boolean.FALSE);
                continue;
            }
            blockedMap.put(ID, Boolean.TRUE);
            
            RequestParam param = paramGen.getRandomRequestParams();
            return 
            	new Request( prec.getId(), param.getK(),
            	        prec.getT()*3600, param.getDT(), 
            	        prec.getX(), param.getDX(),
						prec.getY(), param.getDY() ); 
        }
    }
    
    public void clear() throws IOException {
        blockedMap = null;
        timeMap = null; 
        traceReader.close();
    }
    
    public static void main(String[] args) {
        int[] krange = {5, 4, 3, 2};
        double kzipf = 0.6;
        double tmean = 30.0, tvar = 6.0;
        double xmean = 100, xvar = 10;
        double ymean = 100, yvar = 10;
        
        RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar,  xmean,  xvar, ymean,  yvar);
        TraceReader traceReader = new TraceReader("TraceDataTV.dat");
        RequestGenerator reqGen = new RequestGenerator(paramGen, traceReader, 15.0, 3.0);
        
        try {	
            reqGen.init();
            Request req = null;
            while(null != (req = reqGen.nextRequest()) ) {
                System.err.println(req);
                reqGen.releaseObject(req.getId());
            }
            reqGen.clear();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        
    }   
}
