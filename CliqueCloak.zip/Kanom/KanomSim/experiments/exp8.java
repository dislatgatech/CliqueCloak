/*
 * Created on Jan 30, 2004
 */
package KanomSim.experiments;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;

/**
 * @author Bugra Gedik
 */
public class exp8 extends exp {

    void run() {
        int[] krange = {5, 4, 3, 2};
        double kzipf = 0.6;
        
        double cvft = 0.2;
        double cvfs = 0.2;
        
        
        for(double tmean=10; tmean<=60; tmean+=10) {
exp.sendMail("Exp state: "+tmean);

            //writeToDataFile(cvft+" ");
            for(double xmean=50, ymean = 50; xmean<=150; xmean+=25, ymean+=25) {
                RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, 
        	                                                           tmean, cvft*tmean, 
					                                                   xmean, cvfs*xmean, 
					                                                   ymean, cvfs*ymean);
                TraceReader traceReader = new TraceReader("TraceDataTV.dat");
                RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15.0, 3.0);
        
                Simulator sim = new Simulator();
                sim.configure(requestGenerator);
        
                sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL);
                writeToDescriptionFileLn(sim.getDescription());
                try {	
                    sim.init();
                    sim.start();
                } catch(Exception e) {
                    e.printStackTrace();
                    System.exit(1);
                }
                Statistics stat = sim.getStatistics();
                double succ = stat.getNumOfAnonimizedMessages() / (double) (stat.getNumOfAnonimizedMessages() + stat.getNumOfDroppedMessages());
                writeToDataFile(succ+" ");
            }
            writeToDataFileLn("");
        }
        
    }

}