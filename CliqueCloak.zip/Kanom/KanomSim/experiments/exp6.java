/*
 * Created on Jan 25, 2004
 */
package KanomSim.experiments;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;

/**
 * @author Bugra Gedik
 */
public class exp6 extends exp {

    void run() {
        int[] krange = {5, 4, 3, 2};
        double kzipf = 0.6;
        double tmean = 30.0, tvar = 6.0;
        double xmean = 100, xvar = 10;
        double ymean = 100, yvar = 10;
        
        RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar, 
                xmean,  xvar, ymean,  yvar);
        TraceReader traceReader = new TraceReader("TraceDataTV.dat");
        RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15.0, 3.0);
        
        Simulator sim = new Simulator();
        sim.configure(requestGenerator);
        
        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL);
        writeToDescriptionFileLn(sim.getDescription());
        try {	
            sim.init();
            sim.start();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        Statistics stat = sim.getStatistics();
        
        Statistics.Histogram thist = stat.getTemporalHistogram();
        Statistics.Histogram shist = stat.getSpatialHistogram();
        
        
        int nb = shist.getNumberOfBuckets();
        for(int i=1; i<=nb-2; i++) {
            this.writeToDataFileLn((shist.getBucketBegPoint(i)+shist.getBucketEndPoint(i))/2+" "+ 
                                    thist.getBucketValue(i)+" "+shist.getBucketValue(i));
        }
    }

}
