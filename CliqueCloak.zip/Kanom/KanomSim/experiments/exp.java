/*
 * Created on Jan 20, 2004
 */
package KanomSim.experiments;

/**
 * @author Bugra Gedik
 */

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


/**
 * @author Bugra Gedik
 */


public abstract class exp {

    public static void sendMail(String tosend){
        try {
            String smtpHost = "lennon.cc.gatech.edu";
            String from = "bgedik@cc.gatech.edu";
            String to = "bgedik@cc.gatech.edu";
            
            // Get system properties
            Properties props = System.getProperties();

            // Setup mail server
            props.put("mail.smtp.host", smtpHost);

            // Get session
            Session session = 
            Session.getDefaultInstance(props, null);
            
            // Define message
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject(tosend);
            message.setText(tosend);

            // Send message
            Transport.send(message);    
            
            System.err.println(tosend);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    PrintWriter pwde = null;
    PrintWriter pwda = null;
    String name = null;
    
    protected void openFiles(String ext){
        Class mc = this.getClass();
        String nm = mc.getName();
        int k = nm.lastIndexOf('.') + 1;
        nm = nm.substring(k);
        name = new String(nm) + ext;
        
        File edir = new File("exp");
        if(!edir.exists()) {
            if(!edir.mkdir()){
                System.out.println("Unable to create the experiments directory 'exp/'");
                System.exit(1);
            }
        } else if(!edir.isDirectory()) {
            System.out.println("Unable to create the experiments directory 'exp/', a file with the same name exists ");
            System.exit(1);
        }
        
        edir = new File("exp/"+nm);
        if(!edir.exists() && !edir.mkdir()){
            System.out.println("Unable to create the experiments directory '"+nm+"' under 'exp/'");
            System.exit(1);
        }
        
        String nmde = "exp/" + nm + "/" + nm + ext + "-desc.dat"; 
        String nmda = "exp/" + nm + "/" + nm + ext +"-data.dat";
        try {
            pwde = new PrintWriter(new FileWriter(nmde), true);
            pwda = new PrintWriter(new FileWriter(nmda), true);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Unable to create experiment files under"+nm);
            System.exit(1);
        } 
    }    
    
    protected void closeFiles(){
        pwde.flush();
        pwde.close();
        pwda.flush();
        pwda.close();
    }
    
    protected void writeToDescriptionFile(String str){
        pwde.print(str);
    }
    protected void writeToDescriptionFileLn(String str){
        pwde.println(str);
        pwde.flush();
    }
    
    protected void writeToDataFile(String str){
        pwda.print(str);
    }
    protected void writeToDataFileLn(String str){
        pwda.println(str);
    }

    public void perform() {
        perform("");
    }
    
    public void perform(String ext) {
        openFiles(ext);
        System.err.println("Performing experiment "+name);
        run();
        System.err.println("Performed experiment "+name);
        closeFiles();
    }
    abstract void run();
    

    public static void main(String[] args) {
        (new exp1()).perform("ext");
        //(new exp4()).perform();
        
        //(new exp2()).perform(); 
        //(new exp3()).perform(); 

        //(new exp5()).perform();
        
        //(new exp6()).perform();
        //(new exp7()).perform();
        
        //(new exp8()).perform();
        
        //(new exp9()).perform();
        //(new exp10()).perform();
        
        //(new exp11()).perform();
        //(new exp12()).perform();
        //(new exp13()).perform();
        //sendMail("Donedir");
    }
    

    
}
