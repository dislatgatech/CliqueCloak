/*
 * Created on Jun 2, 2004
 */
package KanomSim.experiments;

import java.util.Arrays;
import java.util.HashMap;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;

/**
 * @author Bugra Gedik
 */
public class exp10 extends exp {

    void run() {
        int[] krange = {5, 5, 5, 5};
        double kzipf = 0.6;
        double tmean = 30.0, tvar = 6.0;
        double xmean = 100, xvar = 15;
        double ymean = 100, yvar = 15;
        
        RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar, 
                                                                   xmean,  xvar, ymean,  yvar);
        TraceReader traceReader = new TraceReader("TraceDataTV.dat");
        RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15, 3.0);
        
        Simulator sim = new Simulator();
        sim.configure(requestGenerator);
        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL);
        writeToDescriptionFileLn(sim.getDescription());
        try {   
            sim.init();
            sim.start();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        Statistics stat = sim.getStatistics();
        HashMap klevs = stat.getAnonimityLevels();
        Object[] keys = klevs.keySet().toArray();
        Arrays.sort(keys);
        
        for(int i=0; i<keys.length; i++) 
            System.out.print(keys[i]+" ");
        System.out.println();
        
        HashMap trhm = stat.getRelTResMap();
        HashMap srhm = stat.getRelSResMap();
        
        for(int i=0; i<keys.length; i++) {
            double[] val = (double[]) trhm.get(keys[i]);
            System.out.print(val[0]+" ");
        }           
        System.out.println();

        for(int i=0; i<keys.length; i++) {
            double[] val = (double[]) srhm.get(keys[i]);
            System.out.print(val[0]+" ");
        }           
        System.out.println();
        
        HashMap ksucc = stat.getSuccList();
        HashMap kfail = stat.getFailList();
        double succ, fail, rate;        
        
        for(int i=0; i<keys.length; i++) {
            succ = ((Integer)ksucc.get(keys[i])).doubleValue();
            fail = ((Integer)kfail.get(keys[i])).doubleValue();
            rate = succ / (succ+fail); 
            System.out.print(rate+" ");
        }        
        System.out.println();
        
        writeToDataFile("");
        writeToDataFileLn("");
    }

}