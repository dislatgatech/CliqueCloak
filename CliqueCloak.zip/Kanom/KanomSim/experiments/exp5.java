/*
 * Created on Jan 22, 2004
 */
package KanomSim.experiments;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;

/**
 * @author Bugra Gedik
 */
public class exp5 extends exp {

    private double[] prun(Simulator sim, int ptmode, int pmmode, double dc) {
        double[] val = new double[3];
        
        sim.setMode(ptmode, pmmode);
        sim.setDCParam(dc);
        writeToDescriptionFileLn(sim.getDescription());
        double srt = 0;
        double tpm = 0;
        double ccc = 0;
        double rcnt = 6;
        for(int i=0; i<rcnt; i++) {
            try {	
        	    sim.init();
        	    sim.start();
        	} catch(Exception e) {
            	e.printStackTrace();
            	System.exit(1);
        	}
        	Statistics stat = sim.getStatistics();
        	tpm += stat.getSimTime() / stat.getNumOfTotalMessages(); 
        	srt +=  stat.getNumOfAnonimizedMessages() / 
        	                     (double) (stat.getNumOfAnonimizedMessages() + stat.getNumOfDroppedMessages())  ;
        	ccc += stat.getCliqueCallCount();
        }
        val[0] = tpm / rcnt;
        val[1] = srt / rcnt;
        val[2] = ccc / rcnt;
        return val;
    }
    
    public void run() {
        int[] krange = {5, 4, 3, 2};
        double kzipf = 0.6;
        double tmean = 30.0, tvar = 6.0;
        double xmean = 100, xvar = 10;
        double ymean = 100, yvar = 10;

        RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar, 
                xmean,  xvar, ymean,  yvar);
        TraceReader traceReader = new TraceReader("TraceDataTV.dat");
        RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15.0, 3.0);

        Simulator sim = new Simulator();
        sim.configure(requestGenerator);
        
        double[] val = null;
        
exp.sendMail("0");        
        val = prun(sim, Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL, 0.0);
        writeToDataFileLn(val[0]+" "+val[1]+" "+val[2]);
        
exp.sendMail("1");
        val = prun(sim, Simulator.PT_IMMEDIATE, Simulator.PM_LOCAL, 0.0);
        writeToDataFileLn(val[0]+" "+val[1]+" "+val[2]);

exp.sendMail("2");
        val = prun(sim, Simulator.PT_DEFERRED, Simulator.PM_GLOBAL, 2);
        writeToDataFileLn(val[0]+" "+val[1]+" "+val[2]);
        
exp.sendMail("3");
        val = prun(sim, Simulator.PT_DEFERRED, Simulator.PM_LOCAL, 2);
        writeToDataFileLn(val[0]+" "+val[1]+" "+val[2]);        
    }

}


