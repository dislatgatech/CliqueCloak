/*
 * Created on Jan 25, 2004
 */
package KanomSim.experiments;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;

/**
 * @author Bugra Gedik
 */
public class exp7 extends exp {

    void run() {
        int[] krange = {5, 4, 3, 2};
        double kzipf = 0.6;
        double tmean = 30.0;
        double xmean = 100;
        double ymean = 100;
        
        double vft = 0.2;
        double vfs = 0.2;
        double[] sfrange = {0.5, 0.75, 1, 1.25, 1.5};
        
        double[][][] results = new double[sfrange.length][][];
        
        for(int si=0; si<sfrange.length; si++) {
exp.sendMail("Exp state: "+si);
            double sf = sfrange[si]; 
        	RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, 
        	                                                           sf*tmean,  vft*sf*tmean, 
        	                                                           sf*xmean, vfs*sf*xmean, 
																	   sf*ymean, vfs*sf*ymean);
        	TraceReader traceReader = new TraceReader("TraceDataTV.dat");
        	RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15.0, 3.0);
        
        	Simulator sim = new Simulator();
        	sim.configure(requestGenerator);
        
        	sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL);
        	writeToDescriptionFileLn(sim.getDescription());
        	try {	
        	    sim.init();
        	    sim.start();
        	} catch(Exception e) {
        	    e.printStackTrace();
        	    System.exit(1);
        	}
        	Statistics stat = sim.getStatistics();
        
        	Statistics.Histogram thist = stat.getTemporalHistogram();
        	Statistics.Histogram shist = stat.getSpatialHistogram();
        
        	double tsum = 0;
        	double ssum = 0;
        	int nb = shist.getNumberOfBuckets();
        	results[si] = new double[nb-2][3];
        	for(int i=1; i<=nb-2; i++) {
        	    results[si][i-1][0] = (shist.getBucketBegPoint(i)+shist.getBucketEndPoint(i))/2; 
                tsum += thist.getBucketValue(i);
                ssum += shist.getBucketValue(i);
        	    results[si][i-1][1] = tsum;
                results[si][i-1][2] = ssum;
        	}
        }
        
        // rel tsum1 tsum2 ... tsumn ssum1 ssum2 ... ssumn 
        int nrows = results[0].length;        
        for(int i=0; i<nrows; i++) {
            writeToDataFile(results[0][i][0]+" ");
            for(int j=0;j<sfrange.length; j++)
                writeToDataFile(results[j][i][1]+" ");
            for(int j=0;j<sfrange.length; j++)    
                writeToDataFile(results[j][i][2]+" ");
            writeToDataFileLn("");
        }
    }

}