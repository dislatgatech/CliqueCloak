/*
 * Created on Jan 20, 2004
 */
package KanomSim.experiments;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;

/**
 * @author Bugra Gedik
 */
public class exp3 extends exp{
    // success rate for different (iat, dx, dy) pairs
    
    public void run() { 
        int[] krange = {5, 4, 3, 2};
        double kzipf = 0.6;
        double tmean = 30.0, tvar = 6.0;
        
        double[] xymean_range = {50, 75, 100, 125, 150};
        double[] iat_range = {10, 20, 30, 40, 50, 60};
        double valp = 0.2;
        double xyalp = 0.1;
        
        Simulator sim = new Simulator();
        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL);
        TraceReader traceReader = new TraceReader("TraceDataTV.dat");
        
        for(int i=0; i<iat_range.length; i++) {
            for(int t=0; t<xymean_range.length; t++) {
exp.sendMail(i+" "+t);
                RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar, 
                                                                           xymean_range[t], xyalp * xymean_range[t], 
																		   xymean_range[t], xyalp * xymean_range[t]);
                RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, iat_range[i], valp * iat_range[i]);
        
               	sim.configure(requestGenerator);
               	writeToDescriptionFileLn(sim.getDescription());
                
               	int rpt = 4;
               	double srate = 0; 
               	for(int u=0; u<rpt; u++) {
               		try {	
               		    sim.init();
               		    sim.start();
               		} catch(Exception e) {
               		    e.printStackTrace();
               		    System.exit(1);
               		}

                    Statistics stat = sim.getStatistics();
        
                    double ksucc = stat.getNumOfAnonimizedMessages();  
                    double kfail = stat.getNumOfDroppedMessages();
                    srate += ksucc / (kfail+ksucc);        
               	}
               	srate /= rpt;
                writeToDataFileLn(iat_range[i]+" "+xymean_range[t]+" "+srate);

            }
        }
        
    }    
}

