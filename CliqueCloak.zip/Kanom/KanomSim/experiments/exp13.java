/*
 * Created on Feb 10, 2005
 *
 */
package KanomSim.experiments;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;
import com.vladium.utils.SystemInformation;

/**
 * @author Bugra Gedik
 *
 */
public class exp13 extends exp {
    
    void run() {    
        int[] krange = {0};
        double kzipf = 1;
        double tmean_b = 30.0, tvar = 6.0;
        double xmean_b = 100, xvar = 10;
        double ymean_b = 100, yvar = 10;
        double tmean, xmean, ymean;
 
        int[] kvls = {4, 12};
        double[] sfs = {1, 1.5, 2, 2.5, 3};
        for(int i=0; i<sfs.length; ++i) {
            double sf = sfs[i];
            tmean = sf * tmean_b;
            xmean = sf * xmean_b;
            ymean = sf * ymean_b;
            for(int j=0; j<kvls.length; ++j) {
                for(int z=0; z<2; z++) {
System.err.println(i+" "+j);                
                    krange[0] = kvls[j];
                    RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar, xmean,  xvar, ymean,  yvar);
                    TraceReader traceReader = new TraceReader("TraceDataTV.dat");
                    RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15, 3);
                   
                    Simulator sim = new Simulator();
                    sim.configure(requestGenerator);
                    if(z==0) 
                        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL);
                    else 
                        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL_PROGRESSIVE);
                    writeToDescriptionFileLn(sim.getDescription());
                    try {   
                        sim.init();
                        long stime = SystemInformation.getProcessCPUTime();
                        sim.start();
                        long etime = SystemInformation.getProcessCPUTime();
                        Statistics stat = sim.getStatistics();
                        double ksucc = stat.getNumOfAnonimizedMessages();  
                        double kfail = stat.getNumOfDroppedMessages();
                        double srate = ksucc / (kfail+ksucc);   
                        double pmpt = (double)(etime-stime) / stat.getNumOfTotalMessages();
                        writeToDataFileLn(z+" "+sf+" "+kvls[j]+" "+srate+" "+pmpt);
                    } catch(Exception e) {
                        e.printStackTrace();
                        System.exit(1);
                    }
                }
            }
         
        }
    }
}
