/*
 * Created on Jan 21, 2004
 */
package KanomSim.experiments;

/**
 * @author Bugra Gedik
 */

import java.util.Arrays;
import java.util.HashMap;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;

public class exp4 extends exp {

    // anonimity levels for different ks and approaches
    public void run() { 
        int[] krange = {5, 4, 3, 2};
        double kzipf = 0.6;
        double tmean = 30.0, tvar = 6.0;
        double xmean = 100, xvar = 10;
        double ymean = 100, yvar = 10;
        
        double[][] results = new double[krange.length][2];
        
        RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar, 
                xmean,  xvar, ymean,  yvar);
        TraceReader traceReader = new TraceReader("TraceDataTV.dat");
        RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15.0, 3.0);
        
        Simulator sim = new Simulator();
        sim.configure(requestGenerator);
        
        /* 1 */
        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL);
        writeToDescriptionFileLn(sim.getDescription());
        try {	
            sim.init();
            sim.start();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        Statistics stat = sim.getStatistics();
        HashMap klevs = stat.getAnonimityLevels();
        Object[] keys = klevs.keySet().toArray();
        Arrays.sort(keys);
        for(int i=0; i<keys.length; i++) {
            Integer K = (Integer) keys[i];
            int k = K.intValue();
            double lev = ((Double)klevs.get(K)).doubleValue(); 
            results[i][0] = lev; 
        }        
        
        /* 2 */
        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_LOCAL);
        writeToDescriptionFileLn(sim.getDescription());
        try {	
            sim.init();
            sim.start();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        stat = sim.getStatistics();
        klevs = stat.getAnonimityLevels();
        keys = klevs.keySet().toArray();
        Arrays.sort(keys);
        for(int i=0; i<keys.length; i++) {
            Integer K = (Integer) keys[i];
            int k = K.intValue();
            double lev = ((Double)klevs.get(K)).doubleValue(); 
            results[i][1] = lev; 
        }           
        
        Arrays.sort(krange);
        for(int i=0; i<results.length; i++) {
            writeToDataFile(krange[i]+" ");
            for(int j=0; j<results[0].length; j++) {
                writeToDataFile(results[i][j]+" ");
            }
            writeToDataFileLn("");
        }
        return;
    }
}
