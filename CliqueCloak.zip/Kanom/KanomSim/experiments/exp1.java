/*
 * Created on Jan 20, 2004
 */
package KanomSim.experiments;

import java.util.Arrays;
import java.util.HashMap;

import KanomSim.RequestGenerator;
import KanomSim.RequestParamGenerator;
import KanomSim.Simulator;
import KanomSim.Statistics;
import TraceGenerator.TraceUtils.TraceReader;

/**
 * @author Bugra Gedik
 */
public class exp1 extends exp{
    
    // success rate for different k's and methods
    public void run() { 
        int[] krange = {5, 4, 3, 2};
        double kzipf = 0.6;
        double tmean = 30.0, tvar = 6.0;
        double xmean = 100, xvar = 10;
        double ymean = 100, yvar = 10;
        
        double[][] results = new double[krange.length+1][4];
        
        RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar, 
                                                                   xmean,  xvar, ymean,  yvar);
        TraceReader traceReader = new TraceReader("TraceDataTV.dat");
        RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15.0, 3.0);
        
        Simulator sim = new Simulator();
        sim.configure(requestGenerator);
        
        /* 1 */
        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_GLOBAL);
        writeToDescriptionFileLn(sim.getDescription());
        try {	
            sim.init();
            sim.start();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        Statistics stat = sim.getStatistics();
        
        HashMap ksucc = stat.getSuccList();
        HashMap kfail = stat.getFailList();
        HashMap kforce = stat.getForceList();
        HashMap klevs = stat.getAnonimityLevels();
        double succ, fail, force, rate;
        
        Object[] keys = klevs.keySet().toArray();
        Arrays.sort(keys);
        for(int i=0; i<keys.length; i++) {
            Integer K = (Integer) keys[i];
            int k = K.intValue();
            succ = ((Integer)ksucc.get(K)).doubleValue();
            fail = ((Integer)kfail.get(K)).doubleValue();
            rate = succ / (succ+fail); 
            results[i][0] = rate;
            force = ((Integer)kforce.get(K)).doubleValue();
            rate = force / (succ+fail);            
            results[i][1] = rate;
        }        
        succ = stat.getNumOfAnonimizedMessages();
        fail = stat.getNumOfDroppedMessages();
        force = stat.getNumOfForcedDrops();
        rate = succ / (succ+fail);
        results[keys.length][0] = rate;
        rate = force / (succ+fail);
        results[keys.length][1] = rate;
        
        /* 2 */
        sim.setMode(Simulator.PT_IMMEDIATE, Simulator.PM_LOCAL);
        writeToDescriptionFileLn(sim.getDescription());
        try {	
            sim.init();
            sim.start();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        stat = sim.getStatistics();
        
        ksucc = stat.getSuccList();
        kfail = stat.getFailList();
        kforce = stat.getForceList();
        klevs = stat.getAnonimityLevels();
        
        keys = klevs.keySet().toArray();
        Arrays.sort(keys);
        for(int i=0; i<keys.length; i++) {
            Integer K = (Integer) keys[i];
            int k = K.intValue();
            succ = ((Integer)ksucc.get(K)).doubleValue();
            fail = ((Integer)kfail.get(K)).doubleValue();
            rate = succ / (succ+fail); 
            results[i][2] = rate;
            force = ((Integer)kforce.get(K)).doubleValue();
            rate = force / (succ+fail);            
            results[i][3] = rate;
        }        
        succ = stat.getNumOfAnonimizedMessages();
        fail = stat.getNumOfDroppedMessages();
        force = stat.getNumOfForcedDrops();
        rate = succ / (succ+fail);
        results[keys.length][2] = rate;
        rate = force / (succ+fail);
        results[keys.length][3] = rate;
        
        Arrays.sort(krange);
        for(int i=0; i<results.length; i++) {
            if(i!=results.length-1)
                writeToDataFile(krange[i]+" ");
            else
                writeToDataFile("all ");
            for(int j=0; j<results[0].length; j++) {
                writeToDataFile(results[i][j]+" ");
            }
            writeToDataFileLn("");
        }
        return;
    }    
}
