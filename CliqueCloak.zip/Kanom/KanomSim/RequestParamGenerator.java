/*
 * Created on Jan 20, 2004
 */
package KanomSim;

import java.util.Date;
import java.util.Random;

import utils.Zipf;

/**
 * @author Bugra Gedik
 */
public class RequestParamGenerator {
    private double tmean;
    private double xmean;
    private double ymean;
    private int[] krange;
    
    private double kzipf;
    private double tvar;
    private double xvar;
    private double yvar;
    
    private Zipf kz = null;
    private Random rd = null;
    
    public RequestParamGenerator(int[] krange, double kzipf,
						 double tmean, double tvar,
						 double xmean, double xvar,
						 double ymean, double yvar) {
        
        this.krange = krange;
        this.kzipf = kzipf;
        this.tmean = tmean;
        this.tvar = tvar;
        this.xmean = xmean;
        this.xvar = xvar;
        this.ymean = ymean;
        this.yvar = yvar;
        
        initKZipf();
        rd = new Random((new Date()).getTime());
    }
    
    private void initKZipf() {
        kz = new Zipf(kzipf, krange.length);  
    }
    
    public void setTMean(double tmean) { this.tmean = tmean; }
    public double getTMean() { return tmean; }    
    public void setTVar(double tvar) { this.tvar = tvar; }
    public double getTVar() { return tvar; }    
    
    public void setXMean(double xmean) { this.xmean = xmean; }
    public double getXMean() { return xmean; }    
    public void setXVar(double xvar) { this.xvar = xvar; }
    public double getXVar() { return xvar; }    
    
    public void setYMean(double ymean) { this.ymean = ymean; }
    public double getYMean() { return ymean; }    
    public void setYVar(double yvar) { this.yvar = yvar; }
    public double getYVar() { return yvar; }    
    
    public void setK(int[] krange, double kzipf) {
        this.krange = krange;
        this.kzipf = kzipf;
        initKZipf();
    }
    public int[] getKRange() { return krange; }
    public double getKZipf() { return kzipf; }
    
    public RequestParam getRandomRequestParams() {
        int k = krange[kz.getRandomValue()];
        double dt = Math.abs( tmean + rd.nextGaussian()*Math.sqrt(tvar) );
        double dx = Math.abs( xmean + rd.nextGaussian()*Math.sqrt(xvar) );
        double dy = Math.abs( ymean + rd.nextGaussian()*Math.sqrt(yvar) );
        return new RequestParam(k, dt, dx, dy);
    }
}

class RequestParam {
    private int k;
    private double dt;
    private double dx; 
    private double dy;
    
    public RequestParam(int k, double dt, double dx, double dy) {
        this.k = k;
        this.dt = dt;
        this.dx = dx;
        this.dy = dy;
    }
    public int getK() {
        return k;
    }
    public double getDT() {
        return dt;
    }
    public double getDX() {
        return dx;
    }
    public double getDY() {
        return dy;
    }    
}

