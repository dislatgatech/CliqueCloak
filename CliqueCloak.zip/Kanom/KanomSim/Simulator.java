/*
 * Created on Jan 14, 2004
 */
package KanomSim;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

import spatialindex.rtree.RTree;
import spatialindex.spatialindex.IData;
import spatialindex.spatialindex.INode;
import spatialindex.spatialindex.IVisitor;
import spatialindex.spatialindex.Point;
import spatialindex.storagemanager.IStorageManager;
import spatialindex.storagemanager.MemoryStorageManager;
import spatialindex.storagemanager.PropertySet;
import spatialindex.spatialindex.Region;
import BGGraph.DynUGraph;
import CombUtils.CombListener;
import CombUtils.CombUtils;
import TraceGenerator.TraceUtils.TraceReader;
import com.vladium.utils.timing.*;

/**
 * @author Bugra Gedik
 */
public class Simulator {
    public static final int PM_LOCAL = 0;
    public static final int PM_GLOBAL = 1;
    public static final int PM_GLOBAL_PROGRESSIVE = 2;
    public static final int PT_IMMEDIATE = 0;
    public static final int PT_DEFERRED = 1;
    
    private int pt_mode;
    private int pm_mode;
    
    private RequestGenerator requestGenerator = null;
    
    private Statistics statistics = null;
    private DynUGraph ugraph = null;
    private HashMap requests = null;
    private RTree sindex = null;
    private TreeSet heap = null;
    private SVisitor visitor = null;
    // maxks stores the total number of neighbors the request has had
    private HashMap maxks = null;
    private ITimer timer = TimerFactory.newTimer();
  
    public Simulator() {
        pm_mode = PM_LOCAL;
        pt_mode = PT_IMMEDIATE;
        statistics = new Statistics();
        ugraph = new DynUGraph();
        requests = new HashMap();
        heap = new TreeSet();
        visitor = new SVisitor();
        maxks = new HashMap();
    }
    
    public void configure(RequestGenerator requestGenerator) {
        this.requestGenerator = requestGenerator;
    }
    
    public void setMode(int pt, int pm) {  
        pt_mode = pt;
        pm_mode = pm;
    }
    
    public Statistics getStatistics() {
        return statistics;
    }    
    
    public void init() {
        statistics.clear();
        ugraph.clear();
        requests.clear();
        initSpatialIndex();
        heap.clear();
        msIndexTime = 0;
    }
   
    private void initSpatialIndex() {
        IStorageManager memoryfile = new MemoryStorageManager();
        PropertySet ps = new PropertySet();
        Double f = new Double(0.25);
        ps.setProperty("FillFactor", f);
        Integer i = new Integer(12);
        ps.setProperty("IndexCapacity", i);
        ps.setProperty("LeafCapacity", i);
        i = new Integer(512);
        ps.setProperty("PageSize", i);
        i = new Integer(2);
        ps.setProperty("Dimension", i);
        sindex = new RTree(ps, memoryfile);   
    }
    
    
    public void start() throws IOException {
        statistics.setTime(true);
        if(pt_mode == PT_IMMEDIATE)
            simIMMEDIATE();
        else if(pt_mode == PT_DEFERRED)
            simDEFERRED();
        statistics.setTime(false);
    }

    private void simIMMEDIATE() throws IOException {
        requestGenerator.init();
        Request request = null;
        
        while(null != (request = requestGenerator.nextRequest())) {
            double time = request.getT();             

            /* check for dropped messages */
            while(heap.size() != 0) {
                Request trequest = (Request) heap.first();
                if(trequest.getDeadLine() <= time) {                                        
                    statistics.addToNumOfDroppedMessages(1, trequest.getK());
                    Integer km = (Integer) maxks.get(new Integer(trequest.getId()));
                    if(km==null || km.intValue() < trequest.getK()-1) 
                        statistics.addToNumOfForcedDrops(1, trequest.getK());
                    removeRequest(trequest);
                } 
                else break;
            }
            
            addRequest(request);
            statistics.addToNumOfTotalMessages(1);

            /* attempt to anonimize messages */
            ArrayList orequests = null;

            if(pm_mode == PM_LOCAL)
                orequests = FindLOCAL(request);
            else if(pm_mode == PM_GLOBAL)
                orequests = FindGLOBAL(request);
            else if(pm_mode == PM_GLOBAL_PROGRESSIVE)
                orequests = FindGLOBALPROGRESSIVE(request);
            
            if(orequests != null) {
                updateAnomStats(orequests);
                for(Iterator it = orequests.iterator(); it.hasNext();) {
                    Request arequest = (Request) it.next();
                    removeRequest(arequest);
                    statistics.addToNumOfAnonimizedMessages(1, arequest.getK());
                }
            }
        }
        
        requestGenerator.clear();
    }
    
    private void simDEFERRED() throws IOException {   
        requestGenerator.init();
        Request request = null;
        
        double time = 0;
        while( null != (request = requestGenerator.nextRequest()) || heap.size() != 0) {
            if(request != null) 
                time = request.getT();             
            /* attempt to anonimize messages */
            while(heap.size() != 0) {
                Request trequest = (Request) heap.first();           

                if(trequest.getDeadLine() <= time || request == null) {
                    ArrayList orequests = null;
                    if(pm_mode == PM_LOCAL)
                        orequests = FindLOCAL(trequest);
                    else if(pm_mode == PM_GLOBAL)
                        orequests = FindGLOBAL(trequest);
                    else if(pm_mode == PM_GLOBAL_PROGRESSIVE)
                        orequests = FindGLOBALPROGRESSIVE(request);
                    if(orequests != null) {
                        updateAnomStats(orequests);
                        for(Iterator it = orequests.iterator(); it.hasNext();) { 
                            Request arequest = (Request) it.next();
                            statistics.addToNumOfAnonimizedMessages(1, arequest.getK());
                            removeRequest(arequest);
                        }
                    } 
                    else {
                        if(request != null) {
                            statistics.addToNumOfDroppedMessages(1, trequest.getK());
                            Integer km = (Integer) maxks.get(new Integer(trequest.getId()));
                            if(km==null || km.intValue() < trequest.getK()-1)
                                statistics.addToNumOfForcedDrops(1, trequest.getK());        
                        }
                        removeRequest(trequest);                      
                    }
                } 
                else break;
            }
            if(request != null) { 
                addRequest(request);
                statistics.addToNumOfTotalMessages(1);
                
                if(ugraph.getNumberOfNeighbors(request.getId()) > dcparam * request.getK()) {
                    ArrayList orequests = null;
                    if(pm_mode == PM_LOCAL)
                        orequests = FindLOCAL(request);
                    else if(pm_mode == PM_GLOBAL)
                        orequests = FindGLOBAL(request);
                    else if(pm_mode == PM_GLOBAL_PROGRESSIVE)
                        orequests = FindGLOBALPROGRESSIVE(request);
                    if(orequests != null) {
                        updateAnomStats(orequests);
                        for(Iterator it = orequests.iterator(); it.hasNext();) { 
                            Request arequest = (Request) it.next();
                            statistics.addToNumOfAnonimizedMessages(1, arequest.getK());
                            removeRequest(arequest);
                        }
                    }    
                    
                }
            }
        }
        
        requestGenerator.clear();
    } 
    
    private double dcparam = 1.4;
    public void setDCParam(double dcparam) {
        this.dcparam = dcparam;
    }
    public double getDCParam() {
        return dcparam;
    }
    
    public static void main(String[] args) {
        int[] krange = {2, 3, 4, 5};
        double kzipf = 0.6;
        double tmean = 30.0, tvar = 6.0;
        double xmean = 100, xvar = 15;
        double ymean = 100, yvar = 15;
        
        RequestParamGenerator paramGen = new RequestParamGenerator(krange, kzipf, tmean,  tvar, 
                                                                   xmean,  xvar, ymean,  yvar);
        TraceReader traceReader = new TraceReader("TraceDataTV_old.dat");
        RequestGenerator requestGenerator = new RequestGenerator(paramGen, traceReader, 15, 3.0);
        
        Simulator sim = new Simulator();
        sim.configure(requestGenerator);
        sim.setMode(PT_IMMEDIATE, PM_GLOBAL);
        try {	
            sim.init();
            sim.start();
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        Statistics stat = sim.getStatistics();
        System.out.println(stat);
        System.out.println();
    }   
    
    private void updateAnomStats(ArrayList orequests) {
        int size = orequests.size();
        double mint = Double.POSITIVE_INFINITY, maxt = Double.NEGATIVE_INFINITY;
        double minx = Double.POSITIVE_INFINITY, maxx = Double.NEGATIVE_INFINITY;
        double miny = Double.POSITIVE_INFINITY, maxy = Double.NEGATIVE_INFINITY;
        for(Iterator it = orequests.iterator(); it.hasNext();) {
            Request crequest =  (Request) it.next();
            if(crequest.getX() < minx) minx = crequest.getX();
            if(crequest.getX() > maxx) maxx = crequest.getX();
            if(crequest.getY() < miny) miny = crequest.getY();
            if(crequest.getY() > maxy) maxy = crequest.getY();
            if(crequest.getT() < mint) mint = crequest.getT();
            if(crequest.getT() > maxt) maxt = crequest.getT();
        }

        double area = (maxx-minx) * (maxy-miny); 
        double interval = maxt-mint;

        if(area==0 || interval==0) return;

        for(Iterator it = orequests.iterator(); it.hasNext();) {
            Request crequest = (Request) it.next();
                    
            statistics.updateAnonimityLevels(crequest.getK(), size);
            statistics.updateRelSResolution(crequest.getSRegion().getArea(), area, crequest.getK());
            statistics.updateRelTResolution(2*crequest.getDT(), interval, crequest.getK());
        }
    }
    
    private void addRequest(Request request) {
        /* update data structures with the new message */
        int objId = request.getId();
        requests.put(new Integer(objId), request);
        // add the request into ugraph as a node
        boolean added = ugraph.addNode(objId, 0);

        // add the request into heap
        heap.add(request);
        
        timer.reset(); timer.start();
        // add the edges into ugraph  
        visitor.clear();
        sindex.containmentQuery(request.getSRegion(), visitor);
        ArrayList nids = visitor.getIds();
        Point reqPnt = request.getPoint();
        double tend = request.getDeadLine();
        double tbeg = request.getT() - request.getDT(); 
        for(Iterator it = nids.iterator(); it.hasNext();) {
            Integer nID = ((Integer) it.next()); 
            int nId = nID.intValue();
            Request nrequest = (Request) requests.get(nID);
            if( nrequest.getT() >= tbeg && nrequest.getT() <= tend && 
                nrequest.getRegion().contains(reqPnt)
            ) {
                ugraph.addEdge(objId, nId, 0);             
                
                int nnbr = 0;
                Integer mk = (Integer) maxks.get(nID);
                if(mk != null) 
                    nnbr = mk.intValue();
                nnbr = nnbr + 1;
                maxks.put(nID, new Integer(nnbr));                   
            }
        }
        // add the request into spatial index        
        sindex.insertData(null, request.getSPoint(), objId);
        timer.stop();
        msIndexTime += timer.getDuration();
    }
    
    public double msIndexTime;
    
    private void removeRequest(Request request) {
        int id = request.getId();
        Integer ID = new Integer(id);
        requests.remove(ID);
        ugraph.removeNode(id);
        heap.remove(request);
        
        timer.reset(); timer.start();
        sindex.deleteData(request.getSPoint(), id);
        timer.stop();
        msIndexTime += timer.getDuration();
        
        requestGenerator.releaseObject(id);        
        maxks.remove(ID);
    }
   
    private ArrayList FindGLOBAL(Request request) {
        int[] maxEnum = {Integer.MAX_VALUE, 0};
        return FindGLOBALGeneric(request, request.getSRegion(), maxEnum);
    } 
     
    private double MAX_SCALE_FACTOR = 2;
    private ArrayList FindGLOBALPROGRESSIVE(Request request) {
        int scaleFactor = 1;
        int mk = request.getK();
        Region mreg = request.getSRegion();
        double oarea = mreg.getArea();
        double density = (double) sindex.getStatistics().getNumberOfData() / sindex.getRootMBR().getArea();
        ArrayList result = null;
        
        double [] p_low = {0.0, 0.0};
        double [] p_hgh = {0.0, 0.0};
        int[] krange = requestGenerator.getRequestParamGenerator().getKRange();
        int maxK = krange[krange.length-1];
        int[] maxEnum = { (int)(maxK  * MAX_SCALE_FACTOR), 0};
        boolean underLimit = true;
        while(result == null && underLimit) {
            scaleFactor = scaleFactor + 1;
            double enuma = mk * scaleFactor;
            double earea = (double) enuma / density;
            double scale = Math.sqrt(earea / oarea);
            if(scale > 1) {
                scale = 1;
                underLimit = false;
            }
            p_low[0] = mreg.getLow(0) + 0.5*(1.0-scale)* (mreg.getHigh(0) - mreg.getLow(0)); 
            p_low[1] = mreg.getLow(1) + 0.5*(1.0-scale)* (mreg.getHigh(1) - mreg.getLow(1));
            p_hgh[0] = mreg.getHigh(0) - 0.5*(1.0-scale)* (mreg.getHigh(0) - mreg.getLow(0));
            p_hgh[1] = mreg.getHigh(1) - 0.5*(1.0-scale)* (mreg.getHigh(1) - mreg.getLow(1));
            Region creg = new Region(p_low, p_hgh);
            result = FindGLOBALGeneric(request, creg, maxEnum);
            if(maxEnum[1] == -1) 
                underLimit = false;
        }
        return result;
    }
            
    private ArrayList FindGLOBALGeneric(Request request, Region region, int[] maxEnum) {
        statistics.incCliqueCallCount(1);
        
        ArrayList result = null;
        
        int id = request.getId();
        int nn = ugraph.getNumberOfNeighbors(id);
        if(nn < request.getK()-1) {
            maxEnum[1] = -1;
            return result;
        }
        
        ArrayList nbrSet = new ArrayList(); 
        for(int i=0, z=0; i<nn; i++) {
            int cId = ugraph.getNeighborAt(id, i);
            Request crequest = (Request) requests.get(new Integer(cId));
            if(region.contains(new Point(crequest.getSRegion().getCenter()))) { 
                if(++z <= maxEnum[0]) 
                    nbrSet.add(crequest);
                else {
                    maxEnum[1] = -1;
                    break;
                }
            }
        }
        nn = nbrSet.size();
        
        int[] ks = new int[nn+1];
        for(int i=0; i<nn; i++) {
            Request crequest = (Request) nbrSet.get(i);
            ks[i] = crequest.getK();
        }   
        ks[nn] = request.getK();
        Arrays.sort(ks);
        
        CombEventProcessor ceProc = new CombEventProcessor();
        for(int index=nn; index>=0; index--) {
            int k = ks[index];
            if(index!=nn && k == ks[index+1])
                continue;
            if(k < request.getK() )
                break;    
            // form candidate list
            HashMap clist = new HashMap();
            for(int j=0; j<nn; j++) {
                Request crequest = (Request) nbrSet.get(j);
                if(crequest.getK() <= k)
                    clist.put(new Integer(crequest.getId()), crequest);
            }  
            if(clist.size() < k-1) 
                continue;

            // check size requirement
            int psize;
            int csatisfied;
            do{
                csatisfied = 0; 
                psize = clist.size();
                for(Iterator it=clist.values().iterator(); it.hasNext(); ){
                    Request crequest = (Request) it.next();
                    int cId = crequest.getId();
                    int nc = ugraph.getNumberOfNeighbors(cId);
                    int inNbrCnt = 0;
                    for(int j=0; j<nc && inNbrCnt < k-2; j++) {
                        int nId = ugraph.getNeighborAt(cId, j);
                        if(clist.containsKey(new Integer(nId)))
                            inNbrCnt++;
                    }
                    if(inNbrCnt >= k-2) 
                        csatisfied++;
                    else 
                        it.remove();
                }
            } while(csatisfied >= k-1 && psize != clist.size());
            if(csatisfied < k-1) 
                continue;
            
            // NOTE: Sort step skipped
            int z = 0;
            int[] creqIds = new int[clist.size()];
            for(Iterator it = clist.keySet().iterator(); it.hasNext();)
                creqIds[z++] = ((Integer) it.next()).intValue();
            ceProc.init(id, creqIds);
            CombUtils.generateCombinations(clist.size(), k-1, ceProc);  
            int[] resIds = ceProc.getResult();
            if(resIds != null) {
                result = new ArrayList();
                for(int j=0; j<resIds.length; j++)
                    result.add( requests.get(new Integer(resIds[j])) );
                break;
            }
        }
		return result;
    }
    
    private ArrayList FindLOCAL(Request request) {
        statistics.incCliqueCallCount(1);
        
        ArrayList result = null;
        
        int id = request.getId();
        int k = request.getK();
        int nn = ugraph.getNumberOfNeighbors(id);
        if(nn < k-1) 
            return result;

        CombEventProcessor ceProc = new CombEventProcessor();
        
        // form candidate list
        HashMap clist = new HashMap();
        for(int j=0; j<nn; j++) {
            int cId = ugraph.getNeighborAt(id, j);
            Integer cID = new Integer(cId);
            Request crequest = (Request) requests.get(cID);
            if(crequest.getK() <= k)
                clist.put(cID, crequest);
        }  
        if(clist.size() < k-1) 
            return result;
        
        // check size requirement
        int psize;
        int csatisfied;
        do{
            csatisfied = 0; 
            psize = clist.size();
            for(Iterator it=clist.values().iterator(); it.hasNext();){
                Request crequest = (Request) it.next();
                int cId = crequest.getId();
                int nc = ugraph.getNumberOfNeighbors(cId);
                int inNbrCnt = 0;
                for(int j=0; j<nc && inNbrCnt < k-2; j++) {
                    int nId = ugraph.getNeighborAt(cId, j);
                    if(clist.containsKey(new Integer(nId)))
                        inNbrCnt++;
                }
                if(inNbrCnt >= k-2) 
                    csatisfied++;
                else 
                    it.remove();
            }
        } while(csatisfied >= k-1 && psize != clist.size());
        if(csatisfied < k-1) 
            return result;
        
        // NOTE: Sort step skipped
        int z = 0;
        int[] creqIds = new int[clist.size()];
        for(Iterator it = clist.keySet().iterator(); it.hasNext();)
            creqIds[z++] = ((Integer) it.next()).intValue();
        ceProc.init(id, creqIds);
        CombUtils.generateCombinations(clist.size(), k-1, ceProc);  
        int[] resIds = ceProc.getResult();
        if(resIds != null) {
            result = new ArrayList();
            for(int j=0; j<resIds.length; j++)
                result.add( requests.get(new Integer(resIds[j])) );
        }    
        return result;
    }
    
    class CombEventProcessor implements CombListener{
        int id;
        int[] creqIds = null;
        int[] resIds = null;
        
        public CombEventProcessor() {}
        public void init(int id, int[] creqIds) {
            this.id = id;
            this.creqIds = creqIds;
            resIds = null;
        }
    	public boolean combEvent(int[] event) {
            //for(int i=0; i<event.length; i++)
            //    if(!ugraph.containsEdge(id, creqIds[event[i]]))
            //        return false;
            for(int i=0; i<event.length-1; i++) {
                for(int j=i+1; j<event.length; j++) {
                    if(!ugraph.containsEdge(creqIds[event[i]], creqIds[event[j]]))
                        return false;
                }
            }
            resIds = new int[event.length+1];
            for(int i=0; i<event.length; i++)
                resIds[i] = creqIds[event[i]];
            resIds[event.length] = id;
            return true;
    	}
    	public int[] getResult() {
    	    return resIds;
    	}
	}
    
    class SVisitor implements IVisitor {
        private ArrayList ids = null;
        public SVisitor() {
            ids = new ArrayList();
        }
        public void clear() {
            ids.clear();
        }
        public ArrayList getIds() {
            return ids;
        }
        public void visitData(IData d) {
            int id = d.getIdentifier();
            ids.add(new Integer(id));
        }
        public void visitNode(INode n) {}
        
    }
    
    public String getDescription() {
        RequestParamGenerator rpgen = requestGenerator.getRequestParamGenerator();
        
        int[] krange = rpgen.getKRange();
        double kzipf = rpgen.getKZipf();
        double iat_mean = requestGenerator.getIATMean();
        double iat_var = requestGenerator.getIATVar();
        
        double dt_mean = rpgen.getTMean();
        double dt_var = rpgen.getTVar();
        double dx_mean = rpgen.getXMean();
        double dx_var = rpgen.getXVar();
        double dy_mean = rpgen.getYMean();
        double dy_var = rpgen.getYVar();        
        
        StringBuffer sbuff = new StringBuffer();
        sbuff.append("Mode: "+ ((pt_mode==PT_IMMEDIATE)?"Immediate ":"Deferred ") + ((pm_mode==PM_GLOBAL)?"Global":"Local") + "\n");
        sbuff.append("krange: "+arrayToString(krange)+"\n");
        sbuff.append("kzipf: "+kzipf+"\n");
        sbuff.append("iat(mean,var): "+iat_mean+" "+iat_var+"\n");
        sbuff.append("dt(mean,var): "+dt_mean+" "+dt_var+"\n");
        sbuff.append("dx(mean,var): "+dx_mean+" "+dx_var+"\n");
        sbuff.append("dz(mean,var): "+dy_mean+" "+dy_var+"\n");
        
        return sbuff.toString();
    }
    
    private String arrayToString(int[] a) {
        StringBuffer sbuff = new StringBuffer();
        sbuff.append("[");
        for(int i=0; i<a.length; i++) {
            sbuff.append(a[i]);
            if(i!=a.length-1)
                sbuff.append(",");
        }
        sbuff.append("]");
        return sbuff.toString();
    }
    
}
/*
 * Experiments
 * tecqniques
 *    immediate/deffered 
 *    local/global
 * measures: 
 *   Quality:
 *     main:
 *       success ratio
 *     sub:
 *       rel anonimity level
 *       rel temporal resolution
 *       rel spatial resolution
 *   Performance:
 *     message/minute
 *  
 * variables:
 *    k, dt, dx, dy, iat
*/

