/*
 * Created on Jan 18, 2004
 */
package KanomSim;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @author Bugra Gedik
 */
public class Statistics {
    private int numOfTotalMessages;
    private int numOfAnonimizedMessages;
    private int numOfDroppedMessages;
    private int numOfForcedDrops;
    
    private HashMap anomLevels = null;
    private HashMap anomMsgCounts = null;
    private HashMap forceList = null;
    private HashMap dropList = null;
    private HashMap anomList = null;
    
    private Histogram relSResHist = null;
    private Histogram relTResHist = null;
    private HashMap relSResMap = null;
    private HashMap relTResMap = null;
    
    private double relSpatialResolution;
    private double relTemporalResolution;
    private double temporalExtent;
    private double relSpatial2Resolution;
    private double relTemporal2Resolution;
    private double spatialExtent;
    private double scnt, tcnt;
    
    private double simTime, psimTime; 
    
    private int cliqueCallCount = 0; 
    
    public Statistics() {
        anomLevels = new HashMap();
        anomMsgCounts = new HashMap();
        forceList = new HashMap();
        dropList = new HashMap();
        anomList = new HashMap();
        relSResMap = new HashMap();
        relTResMap = new HashMap();
        
        relSResHist = new Histogram(1, 100, 0.1);
        relTResHist = new Histogram(1, 100, 0.1);
                    
        relSResHist.init();
        relTResHist.init();        
        clear();
    }
    
    public void clear() {
        numOfTotalMessages = 0;
        numOfAnonimizedMessages = 0;
        numOfDroppedMessages = 0;
        numOfForcedDrops = 0;
        temporalExtent = 0;
        spatialExtent = 0;        
        simTime = psimTime = 0;
        
        anomLevels.clear();
        anomMsgCounts.clear();
        relSpatialResolution = 0;
        relTemporalResolution = 0;
        relSpatial2Resolution = 0;
        relTemporal2Resolution = 0;
        scnt = 0; tcnt = 0;
        cliqueCallCount = 0;
        
        relSResMap.clear();
        relTResMap.clear();
        relSResHist.clear();
        relTResHist.clear();
        forceList.clear();
        dropList.clear();
        anomList.clear();
    }
    
    public void incCliqueCallCount(int ccall) {
        cliqueCallCount += ccall;
    }
    public int getCliqueCallCount() {
        return cliqueCallCount;
    }    

    public void updateRelSResolution(double srel, double ssrel, int k) {
        double nscnt = scnt + 1;
        double nrel = Math.sqrt(srel/ssrel);
if(nrel>100) return;
        relSpatialResolution = relSpatialResolution * (scnt/nscnt) + nrel * (1/nscnt);
        relSpatial2Resolution = relSpatial2Resolution * (scnt/nscnt) + (srel/ssrel) * (1/nscnt);
        spatialExtent = spatialExtent * (tcnt/nscnt) + Math.sqrt(ssrel) * (1/nscnt);
        scnt = scnt + 1;
        relSResHist.add(srel/ssrel);

        Integer K = new Integer(k);
        double[] val = (double[]) relSResMap.get(K);
        if(val == null) { 
            val = new double[2];
            val[0] = val[1] = 0.0;
            relSResMap.put(K, val);
        }
        double nval1 = val[1] + 1;
        val[0] = val[0]*(val[1]/nval1) + nrel * (1/nval1);
        val[1] = nval1;
    }
    public HashMap getRelSResMap() {
        return relSResMap;
    }
    public double getRelSResolution() {
        return relSpatialResolution;
    }
    public double getRelSResDeviation() {
        return Math.sqrt( relSpatial2Resolution - Math.pow(relSpatialResolution, 2) );
    }
    public double getAvgSpatialExtent() {
        return spatialExtent;
    }
    public Histogram getSpatialHistogram() {
        return relSResHist;
    }

    public void updateRelTResolution(double trel, double strel, int k) {
        double ntcnt = tcnt + 1;
        double nrel = trel/strel;
if(nrel>100) return;
        relTemporalResolution = relTemporalResolution * (tcnt/ntcnt) + nrel * (1/ntcnt);
        relTemporal2Resolution = relTemporal2Resolution * (tcnt/ntcnt) + Math.pow(trel/strel, 2) * (1/ntcnt);
        temporalExtent = temporalExtent * (tcnt/ntcnt) + strel * (1/ntcnt);
        tcnt = tcnt + 1;
        relTResHist.add(trel/strel);        

        Integer K = new Integer(k);
        double[] val = (double[]) relTResMap.get(K);
        if(val == null) { 
            val = new double[2];
            val[0] = val[1] = 0.0;
            relTResMap.put(K, val);
        }
        double nval1 = val[1] + 1;
        val[0] = val[0]*(val[1]/nval1) + nrel * (1/nval1);
        val[1] = nval1;
    }
    public HashMap getRelTResMap() {
        return relTResMap;
    }
    public double getRelTResolution() {
        return relTemporalResolution;
    }    
    public double getRelTResDeviation() {
        return Math.sqrt( relTemporal2Resolution - Math.pow(relTemporalResolution, 2) );
    }
    public double getAvgTemporalExtent() {
        return temporalExtent;
    }    
    public Histogram getTemporalHistogram() {
        return relTResHist;
    }
    
    public void updateAnonimityLevels(int k, int sk) {
        int pnmsg = 0;
        double plevel = 0; 
        Integer K = new Integer(k);
        Double level = (Double) anomLevels.get(K);
        if(level != null) {
            Integer nmsg = (Integer) anomMsgCounts.get(K);
            plevel = level.doubleValue();
            pnmsg = nmsg.intValue();
        }       								  
        double nlevel = (plevel * pnmsg + (sk/(double)k)) / (1 + pnmsg);
        int nnmsg = pnmsg + 1;
        anomLevels.put(K, new Double(nlevel));
        anomMsgCounts.put(K, new Integer(nnmsg));
    }
    
    public double getAvgAnomLevel() {
        double aalev = 0;
        int tamcnt = 0;
        for(Iterator it=anomMsgCounts.values().iterator(); it.hasNext(); ) 
            tamcnt += ((Integer) it.next()).intValue();
        
        for(Iterator it=anomLevels.keySet().iterator(); it.hasNext(); ) {
            Integer K = (Integer) it.next();
            double level = ( (Double) anomLevels.get(K) ).doubleValue();
            double amcnt = ( (Integer) anomMsgCounts.get(K) ).intValue();
            aalev += level * (amcnt/tamcnt);
        }
        return aalev;
        
    }
    public HashMap getAnonimityLevels() {
        return anomLevels;
    }
    
    public void setTime(boolean start) {
        if(start) 
            psimTime = System.currentTimeMillis()/1000.0;
        else 
            simTime += System.currentTimeMillis()/1000.0 - psimTime;
    }
    public double getSimTime() {return simTime;}
    
    public int getNumOfTotalMessages() { return numOfTotalMessages; }
    public int getNumOfAnonimizedMessages() { return numOfAnonimizedMessages; }    
    public int getNumOfDroppedMessages() { return numOfDroppedMessages; }
    
    public void addToNumOfTotalMessages(int inc) { 
        numOfTotalMessages += inc; 
    }
    public void addToNumOfAnonimizedMessages(int inc, int k) { 
        numOfAnonimizedMessages += inc; 
        Integer K = new Integer(k);
        Integer nmsg =  (Integer) anomList.get(K);
        if(nmsg == null)
            anomList.put(K, new Integer(1));
        else
            anomList.put(K, new Integer(nmsg.intValue()+1));
    }    
    public void addToNumOfDroppedMessages(int inc, int k) { 
        numOfDroppedMessages += inc; 
        Integer K = new Integer(k);
        Integer nmsg =  (Integer) dropList.get(K);
        if(nmsg == null)
            dropList.put(K, new Integer(1));
        else
            dropList.put(K, new Integer(nmsg.intValue()+1));
    }
    public void addToNumOfForcedDrops(int inc, int k) {
        numOfForcedDrops += inc; 
        Integer K = new Integer(k);
        Integer nmsg =  (Integer) forceList.get(K);
        if(nmsg == null)
            forceList.put(K, new Integer(1));
        else
            forceList.put(K, new Integer(nmsg.intValue()+1));
    }
    public int getNumOfForcedDrops() {
    	return numOfForcedDrops;
    }
    
    public HashMap getSuccList() {
        return anomList;
    }
    public HashMap getFailList() {
        return dropList;
    }
    public HashMap getForceList() {
        return forceList;
    }
    
    public String toString() {
        double aalev = getAvgAnomLevel();
        
        return 
        "TotM:"+numOfTotalMessages+", AnnM:"+numOfAnonimizedMessages+", DrpM:"+numOfDroppedMessages+"\n"+
        "AALev:"+aalev+", AList:"+hashMapTS(anomLevels)+"\n"+
        "SList:"+hashMapTS(anomList)+", FList:"+hashMapTS(dropList)+"\n"+
        "RSRes:["+relSpatialResolution+","+getRelSResDeviation()+"], " + "SHist:"+relSResHist+"\n"+
        "RTRes:["+relTemporalResolution+","+getRelTResDeviation()+"], "+ "THist:"+relTResHist+"\n"+
        "TotT:"+simTime;
    }
    private String hashMapTS(HashMap hm) {
        StringBuffer sbuff = new StringBuffer();
        
        Object[] kset = hm.keySet().toArray();
        Arrays.sort(kset);
        
        sbuff.append("[");
        for(int i=0; i<kset.length; i++) {
            double range = ((Number) kset[i]).doubleValue();
            double value = ((Number) hm.get(kset[i])).doubleValue();
            sbuff.append("("+range+","+value+")");
        }
        sbuff.append("]");
        return sbuff.toString();       
    }
    
    public static class Histogram {
        private double[] range = null;
        private int[] values = null;
        
        private double beg;
        private double end;
        private double inc;
        
        private int ne;
        
        public Histogram(double beg, double end, double inc) {
            this.beg = beg;
            this.end = end;
            this.inc = inc;
        }
        
        public void init() {
            ne = (int) Math.ceil((end-beg)/inc) + 2;       
            values = new int[ne];        
        }
        
        public void clear() {
            for(int i=0; i<values.length; i++)
                values[i] = 0;
        }
        
        public void add(double value) {
            if(value < beg)
                values[0]++;
            else if(value >= end) 
                values[values.length-1]++;
            else {
                int index = 1 + (int) Math.floor((value-beg)/inc);    
                values[index]++;
            }
            
        }
        public int getNumberOfBuckets() {
            return ne;
        }
        
        public int getBucketValue(int index) {
            return values[index];
        }
        
        public double getBucketBegPoint(int index) {
            if(index == 0)
                return Double.NEGATIVE_INFINITY;
            else if(index == ne-1)
                return end;
            return beg + (index-1)*inc;
        }
        
        public double getBucketEndPoint(int index) {
            if(index == ne-2)
                return end;
            else if(index == ne-1)
                return Double.POSITIVE_INFINITY;
            return beg + index*inc;
        }
        
        public String toString() {
            StringBuffer buff = new StringBuffer();
            buff.append("{((-Inf,"+beg+"),"+values[0]+"),");
            int i;
            for(i=1; i<values.length-2; i++)
                buff.append("(["+(beg+(i-1)*inc)+","+(beg+i*inc)+"),"+values[i]+"),");
            buff.append("(["+(beg+(i-1)*inc)+","+end+"),"+values[i]+"),");
            buff.append("(("+end+",+Inf),"+values[values.length-1]+")}");
            return buff.toString();
        }
    }
    
}


