/*
 * Created on Dec 6, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package BGGraph;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;


/**
 * @author Bugra Gedik
 *
 */
public class DynDGraph {
	public static final int SUCCESS = 0;
	public static final int INVALID_STREAM_FORMAT = 1;
	public static final int UNABLE_TO_WRITE_STREAM = 2;
	
	protected HashMap nodes = null; 
	protected int numberOfEdges = 0;
	
	public DynDGraph() {
		init();
	}
	private void init() {
		nodes = new HashMap();
	}
	public void clear() {
		nodes.clear();
		numberOfEdges = 0;
	}
	
	public int getNumberOfNodes() {
		return nodes.size();
	}
	public int getNumberOfEdges() {
		return numberOfEdges;
	}	
	
	public int[] getNodeIds() {
		Collection values = nodes.values();
		int[] ids = new int[values.size()];
		int index = 0;
		for(Iterator it=values.iterator(); it.hasNext();) {
			Node node = (Node) it.next();
			int id = node.getId();
			ids[index++] = id;
		}
		return ids;
	}
	
	// returns false if node is already there
	public boolean addNode(int id, double weight) {
		Integer ID = new Integer(id);
		boolean contains = nodes.containsKey(ID);
		if(contains) 
			return false;
		Node nnode = new Node(id, weight);
		nodes.put(ID, nnode);
		return true;
	}
	public boolean containsNode(int id) {
		Integer ID = new Integer(id);
		return nodes.containsKey(ID);
	}
	public boolean removeNode(int id) {
		Integer ID = new Integer(id);
		Node node = (Node) nodes.remove(ID);
		if(node == null) 
			return false;		
		int nto = node.getNumberOfEdges(TO); 		
		for(int i=nto-1; i>=0; i--) {
			Node from = node.getEdgeAt(i, TO).getNode();
			from.removeEdge(node, FROM);
		}
		numberOfEdges -= nto;
		
		int nfrom = node.getNumberOfEdges(FROM); 
		for(int i=nfrom-1; i>=0; i--) {
			Node to = node.getEdgeAt(i, FROM).getNode();
			to.removeEdge(node, TO);
		}
		numberOfEdges -= nfrom;
		return false;
	}
	
	// returns node weight if node exists, unspecified otherwise
	public double getNodeWeight(int id) {
		Integer ID = new Integer(id);
		Node node = (Node) nodes.get(ID);		
		return node.getWeight();
	}
	public boolean setNodeWeight(int id, double weight) {
		Integer ID = new Integer(id);
		Node node = (Node) nodes.get(ID);
		if(node == null)
			return false;
		node.setWeight(weight);
		return true;
	}
	
    // returns false if edge is already there or any of the two nodes does not exist
	public boolean addEdge(int fromId, int toId, double weight) {
		Node from = (Node) nodes.get(new Integer(fromId));
		if(from == null) 
			return false;
		Node to = (Node) nodes.get(new Integer(toId));
		if(to == null) 
			return false;
		
		NodeEdgeEntry nee = from.getEdge(to, FROM);
		if(nee != null) 
			return false;
		
		from.addEdge(to, weight, FROM);
		to.addEdge(from, weight, TO);
		
		numberOfEdges++;
		return true;
	}
	public boolean containsEdge(int fromId, int toId) {
		Node from = (Node) nodes.get(new Integer(fromId));
		if(from == null) 
			return false;
		Node to = (Node) nodes.get(new Integer(toId));
		if(to == null) 
			return false;		
		NodeEdgeEntry nee = from.getEdge(to, FROM);
		return (nee != null);
	}
	public boolean removeEdge(int fromId, int toId) {
		Node from = (Node) nodes.get(new Integer(fromId));
		if(from == null) 
			return false;
		Node to = (Node) nodes.get(new Integer(toId));
		if(to == null) 
			return false;
		
		boolean exists = from.removeEdge(to, FROM);
		if(!exists)
			return false;
		to.removeEdge(from, TO);
		
		numberOfEdges--;		
		return true;
	}
	// unspecified if edge non-exsistant
	public double getEdgeWeight(int fromId, int toId) {
		Node from = (Node) nodes.get(new Integer(fromId));
		if(from == null) 
			return 0;
		Node to = (Node) nodes.get(new Integer(toId));
		if(to == null) 
			return 0;		
		NodeEdgeEntry nee = from.getEdge(to, FROM);
	    return nee.getWeight();
	}
	public boolean setEdgeWeight(int fromId, int toId, double weight) {
		Node from = (Node) nodes.get(new Integer(fromId));
		if(from == null) 
			return false;
		Node to = (Node) nodes.get(new Integer(toId));
		if(to == null) 
			return false;		
		NodeEdgeEntry nee = from.getEdge(to, FROM);
		nee.setWeight(weight);
		nee = to.getEdge(from, TO);
		nee.setWeight(weight);
		return true;
	}
	
	// -1 if node does not exsist
	public int getNumberOfNeighbors(int id, boolean dir) {
		Integer ID = new Integer(id);
		Node node = (Node) nodes.get(ID);
		if(node == null)
			return -1;
		return node.getNumberOfEdges(dir);
	}
	// unspecified if node does not exist
	public int getNeighborAt(int id, int i, boolean dir) {
		Integer ID = new Integer(id);
		Node node = (Node) nodes.get(ID);
		if(node == null)
			return -1;
		NodeEdgeEntry nee = node.getEdgeAt(i, dir);
		return nee.getNode().getId();
	}
    // unspecified if node does not exist
	public double getNeighborLinkWeightAt(int id, int i, boolean dir) {
		Integer ID = new Integer(id);
		Node node = (Node) nodes.get(ID);
		if(node == null)
			return -1;
		NodeEdgeEntry nee = node.getEdgeAt(i, dir);
		return nee.getNode().getWeight();
	}
	
	public int read(InputStream st) { 
		clear();
		BufferedReader br = new BufferedReader(new InputStreamReader(st));
		try {
			while(true) {
				String str = br.readLine();
				if(str == null) 
					break;
				str = str.trim();
				if(str.equals("")) continue;
				StringTokenizer tk = new StringTokenizer(str, ";: \t\n\r\f");
				String idStr = tk.nextToken(); 
				String wtStr = tk.nextToken();
				int fromId = Integer.parseInt(idStr);
				double wt = Double.parseDouble(wtStr);
				if(containsNode(fromId)) 
					setNodeWeight(fromId, wt);
				else
					addNode(fromId, wt);				
				
				while(tk.hasMoreTokens()) {
					idStr = tk.nextToken();
					wtStr = tk.nextToken();
					int toId = Integer.parseInt(idStr);
					wt = Double.parseDouble(wtStr);
					if(!containsNode(toId)) 
						addNode(toId, 0);
					addEdge(fromId, toId, wt);
				}
			}
		} catch(Exception e){
			return INVALID_STREAM_FORMAT;
		}
		return SUCCESS;
	}	
	
	public int write(OutputStream st) {
		BufferedWriter pw = new BufferedWriter(new OutputStreamWriter(st));		
		try{
			Collection values = nodes.values();
			for(Iterator it=values.iterator(); it.hasNext();) {
				Node from = (Node) it.next();
				int fromId = from.getId();
				double wt = from.getWeight();
				pw.write(fromId+";"+wt);
				
				StringBuffer sbuff = new StringBuffer("");
				int n = from.getNumberOfEdges(FROM);	
				for(int i=0; i<n; i++){
					NodeEdgeEntry nee = from.getEdgeAt(i, FROM);
					int toId = nee.getNode().getId();
					wt = nee.getWeight();
					sbuff.append(" "+toId+":"+wt);
				}
				String str = sbuff.toString();
				pw.write(str);
				pw.write("\n");
			}
			pw.flush();
		}catch(IOException e){
			return UNABLE_TO_WRITE_STREAM;
		}
		return SUCCESS;
	}
	
	class Node{
		private int id = 0;
		private double weight = 0;
		private ArrayList toEdges = null; 
		private ArrayList fromEdges = null;
		
		public Node() {
			init();
		}
		public Node(int id, double weight) {
			init();
			this.id = id;
			this.weight = weight;
		}
		private void init() {
			toEdges = new ArrayList();
			fromEdges = new ArrayList();
		}
		
		public void setId(int id) {
			this.id = id;
		}
		public int getId() {
			return id;
		}
		public void setWeight(double weight) {
			this.weight = weight;
		}
		public double getWeight() {
			return weight;
		}		
		
		public int getNumberOfEdges(boolean dir) {
			return (dir==TO)?toEdges.size():fromEdges.size();
		}
		
		public NodeEdgeEntry getEdgeAt(int i, boolean dir) {
			return (NodeEdgeEntry) ((dir==TO)?toEdges.get(i):fromEdges.get(i));
		}
				
		// does not check whether node specified exists or not
		public void addEdge(Node other, double weight, boolean dir) {
			NodeEdgeEntry ne = new NodeEdgeEntry(other, weight); 
			if(dir == TO) {
				// IMPORTANT
				// self edge should be last in order for getNeighborAt op. of DynUGraph to work
				if(other == Node.this)
					toEdges.add(ne);
				else {
					int n = toEdges.size();
					if(n != 0) n--;
					toEdges.add(n, ne);
				}
			} 
			else 
            	fromEdges.add(ne);
		}
		// return false if non-existent
		public boolean removeEdge(Node other, boolean dir) {
			NodeEdgeEntry ne = null;
			ArrayList edges = (dir==TO)?toEdges:fromEdges;
			for(Iterator it=edges.iterator(); it.hasNext();) {
				ne = (NodeEdgeEntry) it.next();
				if(ne.getNode() == other) {
					it.remove();
					return true;
				}
			}
			return false;
		}
		// return edge entry if edge existant, null otherwise
		public NodeEdgeEntry getEdge(Node other, boolean dir) {
			NodeEdgeEntry ne = null;
			ArrayList edges = (dir==TO)?toEdges:fromEdges;
			for(Iterator it=edges.iterator(); it.hasNext();) {
				ne = (NodeEdgeEntry) it.next();
				if(ne.getNode() == other)
					return ne;
			}			
			return null;
		}
	}
	
	public static boolean FROM = true;
	public static boolean TO = false;
	
	class NodeEdgeEntry{
		private Node to = null;
		private double weight = 0;
		
		public NodeEdgeEntry(Node to, double weight) {
			this.to = to;
			this.weight = weight;
		}

		public void setWeight(double weight) {
			this.weight = weight;
		}
		public double getWeight() {
			return weight;
		}		
		
		public void setNode(Node to) {
			this.to = to;
		}
		public Node getNode() {
			return to;
		}		
	}
}







