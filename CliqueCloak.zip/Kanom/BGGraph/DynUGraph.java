/*
 * Created on Dec 7, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package BGGraph;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author Bugra Gedik
 *
 */

public class DynUGraph extends DynDGraph {
	
	public DynUGraph() {
		super();
	}
		
	// returns false if edge is already there or any of the two nodes does not exist
	public boolean addEdge(int fId, int sId, double weight) {
		int minId = (int) Math.min(fId, sId);
		int maxId = (int) Math.max(fId, sId);
		return super.addEdge(minId, maxId, weight);
	}
	public boolean containsEdge(int fId, int sId) {
		int minId = (int) Math.min(fId, sId);
		int maxId = (int) Math.max(fId, sId);
		return super.containsEdge(minId, maxId);
	}
	public boolean removeEdge(int fId, int sId) {
		int minId = (int) Math.min(fId, sId);
		int maxId = (int) Math.max(fId, sId);
		return super.removeEdge(minId, maxId);
	}
	// unspecified if edge non-exsistant
	public double getEdgeWeight(int fId, int sId) {
		int minId = (int) Math.min(fId, sId);
		int maxId = (int) Math.max(fId, sId);
		return super.getEdgeWeight(minId, maxId);
	}
	public boolean setEdgeWeight(int fId, int sId, double weight) {
		int minId = (int) Math.min(fId, sId);
		int maxId = (int) Math.max(fId, sId);
		return super.setEdgeWeight(minId, maxId, weight);
	}
	
	// -1 if node does not exsist
	public int getNumberOfNeighbors(int id) {
		int nfrom = super.getNumberOfNeighbors(id, FROM); 
		int nto = super.getNumberOfNeighbors(id, TO);
		int nall  = nto + nfrom;
		if(super.containsEdge(id, id)) 
			nall = nall - 1;
		return nall;
	}
	// unspecified if node does not exist
	public int getNeighborAt(int id, int i) {
		int nfrom = super.getNumberOfNeighbors(id, FROM); 
		if(i < nfrom)
			return super.getNeighborAt(id, i, FROM);
		else { // assumes that the nodes corresponding to self links are at the end
			i -= nfrom; 
			return super.getNeighborAt(id, i, TO);	
		}
	}
	// unspecified if node does not exist
	public double getNeighborLinkWeightAt(int id, int i) {
		int nfrom = super.getNumberOfNeighbors(id, FROM); 
		if(i < nfrom)
			return super.getNeighborLinkWeightAt(id, i, FROM);
		else { // assumes that the nodes corresponding to self links are at the end
			i -= nfrom; 
			return super.getNeighborLinkWeightAt(id, i, TO);	
		}
	}	
	
	public int write(OutputStream st) {
		BufferedWriter pw = new BufferedWriter(new OutputStreamWriter(st));		
		try{
			Collection values = nodes.values();
			for(Iterator it=values.iterator(); it.hasNext();) {
				Node from = (Node) it.next();
				int fromId = from.getId();
				double wt = from.getWeight();
				pw.write(fromId+";"+wt);
				
				StringBuffer sbuff = new StringBuffer("");
				int n = getNumberOfNeighbors(fromId);	
				for(int i=0; i<n; i++){
					int toId = getNeighborAt(fromId, i);
					wt = getNeighborLinkWeightAt(fromId, i);
					sbuff.append(" "+toId+":"+wt);
				}
				String str = sbuff.toString();
				pw.write(str);
				pw.write("\n");
			}
			pw.flush();
		}catch(IOException e){
			return UNABLE_TO_WRITE_STREAM;
		}
		return SUCCESS;
	}	
}
